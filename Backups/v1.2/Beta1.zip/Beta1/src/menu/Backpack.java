package menu;

import javafx.scene.paint.Color;

import javax.swing.JFrame;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.GridLayout;

import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JRootPane;
import javax.swing.JSplitPane;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;
import javax.swing.border.Border;

import packageBeta.TileThing;
import people.Creature;
import tools.ImageLibrary;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.util.LinkedList;
import javax.swing.border.CompoundBorder;
import javax.swing.border.BevelBorder;
import java.awt.GridBagLayout;
import javax.swing.JScrollPane;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;

public class Backpack extends JDialog
{
	ImageLibrary il = new ImageLibrary();
	private LinkedList<TileThing> bag = new LinkedList<TileThing>();
	private JPanel panel= new JPanel();//main panel
	private LinkedList<TileThing> ground;
	private LinkedList<TileThing> dropList = new LinkedList<TileThing>();
	boolean alreadyAdded = false;
	private JPanel jp;
	private MouseListener mouseListener ;
	
	public Backpack(JFrame parentFrame, String frameTitle, boolean tf)
	{
		super(parentFrame,frameTitle,tf);
		this.setSize(new Dimension(300, 200));
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		
		//this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		this.requestFocus();
		mouseListener = new MouseAdapter() {
		    public void mouseClicked(MouseEvent e) 
		    {
		        if(e.getButton() == MouseEvent.BUTTON3)
			    {
		        	jp = (JPanel)e.getComponent();
		            JPopupMenu menu = new JPopupMenu();
		            JMenuItem drop = new JMenuItem("Drop");
		            drop.addActionListener(new ActionListener(){

						public void actionPerformed(ActionEvent e) {
							removeFromBackpack(jp.getToolTipText());
						}
		            	
		            });
		            menu.add(drop);
		            menu.show(e.getComponent(), e.getX(), e.getY());
			    }
		    }
		};
		JScrollPane scrollPane = new JScrollPane(panel);
		getContentPane().add(scrollPane, BorderLayout.CENTER);
		panel.setLayout(new GridLayout(0, 3, 5, 5));
		scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		
		JPanel panel_2 = new JPanel();
		getContentPane().add(panel_2, BorderLayout.SOUTH);
		FlowLayout flowLayout = (FlowLayout) panel_2.getLayout();
		flowLayout.setAlignment(FlowLayout.RIGHT);
		
		JLabel lblNewLabel = new JLabel("Weight 0/0");
		panel_2.add(lblNewLabel);
		

	}
	
	public void setGround(LinkedList<TileThing> g )
	{
		ground = g;
	}
	
	public LinkedList<TileThing> getGround()
	{
		return ground;
	}
	
	
	public void addToBackpack(TileThing c)
	{
		if(!alreadyAdded)
			bag.add(c);
		
		JPanel newBox = new JPanel();
		newBox.setLayout(new BorderLayout());
		BufferedImage myPicture = il.get(c.getImageID());
		JLabel picLabel = new JLabel(new ImageIcon(myPicture));
		newBox.add(picLabel,BorderLayout.CENTER);
		String itemName = c.getName();
		newBox.setToolTipText(itemName);
		if(itemName.length()>10)
		{
			itemName = itemName.substring(0,8)+"...";
		}
		JLabel text = new JLabel(itemName,SwingConstants.CENTER);
		newBox.add(text,BorderLayout.SOUTH);
		newBox.addMouseListener(mouseListener);
		panel.add(newBox);
		
		repaint();
	}
	
	public LinkedList<TileThing> getDropList()
	{
		return dropList;
	}
	
	public void clearDropList()
	{
		dropList= new LinkedList<TileThing>();
	}
	
	public TileThing removeFromBackpack(String name)
	{
		TileThing n = null;
		//panel.removeAll();
		for (int i = 0; i < bag.size(); i++)
		{
			if(bag.get(i).getName().equals(name))
			{
				panel.remove(jp);
				n = bag.get(i);
				dropList.add(bag.get(i));
				bag.remove(i);
				i--;
			}/**
			else
			{
				alreadyAdded = true;
				addToBackpack(tt);
				alreadyAdded= false;
			}*/
		}
		repaint();
		
		return n;
	}
	
	
	
}
