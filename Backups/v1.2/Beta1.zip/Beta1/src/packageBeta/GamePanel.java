package packageBeta;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import people.*;
import tools.Dice;
import tools.ImageLibrary;
import tools.ModuleLibrary;
import tools.Spellbook;

import javax.imageio.ImageIO;
import javax.swing.*;

public class GamePanel extends JPanel
{
	private Dimension size;
	private TileNode[][] world;//the world on screen
	private TileNode[][] worldView;//the entire world
	private ImageLibrary lib;
	private BufferedImage previousFloorImage;//floor image previousto when player stepped on tile
	private int previousFloorImageID;//id of that image
	private Player p; //current position of the player
	private boolean night;
	
	/**
	 * Constructor. Sets up the Gameworld and the way we view it.
	 * @param size- dimensions of the world.
	 */
	public GamePanel(Dimension size)
	{
		//GRAPHICS SETUP//
		//create our library of tiles to paint the world with
		lib = new ImageLibrary();
		previousFloorImage = lib.get(-1);
		
		//WORLD SETUP//
		//create the new world

		this.size = size;
		int x = size.width;
		int y = size.height;
		
		worldView = new TileNode[x][y];
		//Create a blank world by looping through the size of the map
		//and creating tiles for each grid block
		for(int i = x-1;i>=0;i--)
		{
			for(int j = y-1; j>=0;j--)
			{

				//creates a blank world
				worldView[i][j] = new TileNode(-1,i,j);
			}
		}
		//place corner blocks
		for(int i =0;i<100;i++)
		{
			System.out.println();
			worldView[i][1].setImage(-2);
			worldView[y-1][i].setImage(-8);
			worldView[1][i].setImage(-9);
			worldView[i][y-1].setImage(-5);
			
		}
		worldView[1][1].setImage(-4);
		worldView[y-1][y-1].setImage(-7);
		worldView[1][y-1].setImage(-6);
		worldView[y-1][1].setImage(-3);
		
		//add player to world
		p = new Player("Laindir",new Dimension(x/2,y/2));
		worldView[x/2][y/2].addItem(p);
		//paint stuff in the world
		paintModules();
		//addNPCs
		addNPCs();
		addThings();

		//WORLD VIEW SETUP//
			
		//get screen viewport (player starts at center of map)
		world = new TileNode[21][21];
		
		//this is the x and y coordinates of the top left position
		//the player can see. On a 100x100 grid this is position 40
		x = (x/2)-10;//40 on 100x100
		y = (y/2)-10;//40 on 100x100
		int worldx=0;
		int worldy=0;
		//
		for(int i = x;worldx!=21;i++)
		{
			for(int j = y; worldy!=21;j++)
			{

				//creates a blank world
				TileNode n = worldView[i][j];
				world[worldx][worldy] = n;
				worldy++;
			}
			worldy = 0;
			worldx++;
		}
		
		night = false;

		repaint();
	}
	
	public void addThings()
	{
		worldView[50][50].addItem(new TileThing("Hat"));
		worldView[50][51].addItem(new TileThing("Rock"));
		worldView[50][49].addItem(new TileThing("Toad"));
		worldView[49][50].addItem(new TileThing("Napkin"));
		worldView[51][50].addItem(new TileThing("Turtle"));
		worldView[50][50].addItem(new TileThing("Pickle"));
		worldView[50][51].addItem(new TileThing("Fishstick"));
		worldView[50][49].addItem(new TileThing("Shoe"));
		worldView[49][50].addItem(new TileThing("Dirty Shirt"));
		worldView[51][50].addItem(new TileThing("Really long item name, of excalibur"));
	}
	
	public void addNPCs()
	{
		worldView[45][45].addItem(new Creature("Eldwir",new Dimension(45,45),1000));
		worldView[48][45].addItem(new Creature("Princess Pahlin",new Dimension(48,45),1001));
	}
	
	public void paintModules()
	{
		ModuleLibrary ml = new ModuleLibrary();
		
		int NumOfFailures = 0;
		while(NumOfFailures<ml.getDensity())
		{
			Dice dice = new Dice(20);
			if(dice.roll()>16)
			{
				ml.setModule(1);
			}
			else
			{
				ml.setModule(0);
			}
			Random r = new Random();
			int resultx = r.nextInt(size.width-1)+1;
			int resulty = r.nextInt(size.height-1)+1;
			
			int xStart = 0;
			int yStart = 0;
			
			Dimension d = ml.getModuleSize();
			
			int modulelength = d.height;
			int modulewidth = d.width;
			boolean fail = false;
			
			if(((resultx+modulewidth)<size.width)&((resulty+modulelength)<size.height))
			{
				while(xStart<modulewidth)
				{
					while(yStart<modulelength)
					{
						if(worldView[resultx+xStart][resulty+yStart].isSolid())
						{
							xStart=modulewidth;
							yStart=modulelength;
							fail = true;
						}
						yStart++;
					}
					yStart = 0;
					xStart++;
				}
				xStart=0;
				
				if(!fail)
				{
					worldView = ml.returnAddedModule(worldView, resultx, resulty);
				}
				else
				{
					NumOfFailures++;
				}
			}
		}
		
	}
	
	/**
	 * Gets each tile's image and repaints it.
	 */
	public void paint(Graphics g)
	{
		this.removeAll();
		this.updateUI();
		int coordx = 0;
		int coordy = 0;
		//g.drawImage(lib.get(0),0,0,null);
			
		for(int x = 0;x!=21;x++)
		{
			for(int y=0;y!=21;y++)
			{
				g.drawImage(lib.get(world[x][y].getID()), coordx, coordy,null);
				coordy= coordy+32;
			}
			coordy = 0;
			coordx = coordx+32;
		}
		if(night)
		{
			int alpha = 127; // 50% transparent
			Color myColour = new Color(0, 0, 50, alpha);
			g.setColor(myColour);
			g.fillRect(0, 0, 675, 675);
		}
	}
	
	public void setNight(boolean t)
	{
		night = t;
	}
	
	/*
	 * Move a selected creature in the direction given
	 */
	public void moveCreature(Creature c, String string)
	{
		int x = c.getPosition().width;
		int y = c.getPosition().height;
		
		//if not end of the world
		if(!(x==worldView.length-1))
		{
			//if this is the direction we want
			if(string =="right")
			{
				//and if we can move onto that tile
				if(!(worldView[x+1][y].isSolid())&&(worldView[x+1][y].getID()<1))//if its solid OR someone is standing there already
				{
					//move onto it
					//worldView[x][y].setImage(previousFloorImageID);
					//previousFloorImage = worldView[x+1][y].getImage();
					//previousFloorImageID = worldView[x+1][y].getID();
					//worldView[x+1][y].setImage(lib.get(1),1);
					String uniqueid = p.getCallNum();
					worldView[x][y].removeItem(uniqueid);
					worldView[x+1][y].addItem(p);
					p.moveRight();
					//if we aren't near the end of the map, scroll
					if(x<worldView.length-10&&!(x<11))
						scrollRight();
					else
						repaint();
				}
			}
		}
		if(!(x<=1))
		{
			if(string =="left")
			{
				if(!(worldView[x-1][y].isSolid())&&(worldView[x-1][y].getID()<1))
				{
					//worldView[x][y].setImage(previousFloorImage,previousFloorImageID);
					//previousFloorImage = worldView[x-1][y].getImage();
					//previousFloorImageID = worldView[x-1][y].getID();
					//worldView[x-1][y].setImage(lib.get(1),1);
					//playerAddress.width=playerAddress.width-1;
					String uniqueid = p.getCallNum();
					worldView[x][y].removeItem(uniqueid);
					worldView[x-1][y].addItem(p);
					p.moveLeft();
					if(x>10&&!(x>worldView.length-11))
						scrollLeft();
					else
						repaint();
				}
			}
		}
		if(!(y<=1))
		{
			if(string =="up")
			{
				if(!(worldView[x][y-1].isSolid())&&(worldView[x][y-1].getID()<1))
				{
					//worldView[x][y].setImage(previousFloorImage,previousFloorImageID);
					//previousFloorImage = worldView[x][y-1].getImage();
					//previousFloorImageID = worldView[x][y-1].getID();
					//worldView[x][y-1].setImage(lib.get(1),1);
					//playerAddress.height=playerAddress.height-1;
					String uniqueid = p.getCallNum();
					worldView[x][y].removeItem(uniqueid);
					worldView[x][y-1].addItem(p);
					p.moveUp();
					if(y>10&&!(y>worldView[1].length-11))
						scrollUp();
					else
						repaint();
				}
			}
		}
		if(!(y==worldView[1].length-1))
		{
			if(string =="down")
			{
				if(!(worldView[x][y+1].isSolid())&&(worldView[x][y+1].getID()<1))
				{
					//worldView[x][y].setImage(previousFloorImage,previousFloorImageID);
					//previousFloorImage = worldView[x][y+1].getImage();
					//previousFloorImageID = worldView[x][y+1].getID();
					//worldView[x][y+1].setImage(lib.get(1),1);
					//playerAddress.height=playerAddress.height+1;
					String uniqueid = p.getCallNum();
					worldView[x][y].removeItem(uniqueid);
					worldView[x][y+1].addItem(p);
					p.moveDown();
					if(y<worldView[1].length-10&&!(y<11))
						scrollDown();
					else
						repaint();
				}
			}
		}
	}
	
	public void castSpell(Creature c)
	{
		int x= c.getPosition().width;
		int y = c.getPosition().height;
		Spellbook sb = new Spellbook("Player");
		
	}
	
	/*
	 * Method called when user presses one of the arrow keys.
	 * 
	 * This method should move the player tile on the worldView, then 
	 * adjust the world on the screen 
	 * @parameter String string- the direction of the arrow key pressed
	 * 
	 */
	public void movePlayer(String string) 
	{
		//get players int coords
		int x = p.getPosition().width;
		int y = p.getPosition().height;
		
		
		//
		//
		//System.out.println(x+" ,"+y);
		//
		//
		
		//dont move if at end of map
		if(!(x==worldView.length-1))
		{
			//if this is the direction we want
			if(string =="right")
			{
				//and if we can move onto that tile
				if(!(worldView[x+1][y].isSolid())&&(worldView[x+1][y].getID()<1))//if its solid OR someone is standing there already
				{
					//move onto it
					String uniqueid = p.getCallNum();
					worldView[x][y].removeItem(uniqueid);
					worldView[x+1][y].addItem(p);
					p.moveRight();
					//if we aren't near the end of the map, scroll
					if(x<worldView.length-11&!(x<11))
						scrollRight();
					else
						repaint();
				}
				worldView[x+1][y].poke(p);
			}
		}
		if(!(x<=1))
		{
			if(string =="left")
			{
				if(!(worldView[x-1][y].isSolid())&&(worldView[x-1][y].getID()<1))
				{
					String uniqueid = p.getCallNum();
					worldView[x][y].removeItem(uniqueid);
					worldView[x-1][y].addItem(p);
					p.moveLeft();
					if(x>11&!(x>worldView.length-11))
						scrollLeft();
					else
						repaint();
				}
				worldView[x-1][y].poke(p);
			}
		}
		if(!(y<=1))
		{
			if(string =="up")
			{
				if(!(worldView[x][y-1].isSolid())&(worldView[x][y-1].getID()<1))
				{
					String uniqueid = p.getCallNum();
					worldView[x][y].removeItem(uniqueid);
					worldView[x][y-1].addItem(p);
					p.moveUp();
					if(y>11&!(y>worldView[1].length-11))
						scrollUp();
					else
						repaint();
				}
				worldView[x][y-1].poke(p);
			}
		}
		if(!(y==worldView[1].length-1))
		{
			if(string =="down")
			{
				if(!(worldView[x][y+1].isSolid())&(worldView[x][y+1].getID()<1))
				{
					String uniqueid = p.getCallNum();
					worldView[x][y].removeItem(uniqueid);
					worldView[x][y+1].addItem(p);
					p.moveDown();
					if(y<worldView[1].length-11&!(y<11))
						scrollDown();
					else
						repaint();
				}
				worldView[x][y+1].poke(p);
			}
		}
	}

	public Creature[] returnCreaturesByDexterity()
	{
		ArrayList<Creature> list = new ArrayList<Creature>();
		
		//
		//retrieve each creature in the world
		//
		
		for(TileNode[] n : worldView)
		{
			for(TileNode tn : n)
			{
				Creature joey = (Creature) tn.reportCreature();
				if(joey!=null)
				{
					list.add(joey);
				}
			}
		}
		
		//
		//sort by highest dex next
		//
		//not efficent but easy to implement.
		//
		Creature[] rList = new Creature[list.size()];
		
		int iterator = 0;
		while(list.size()!=0)
		{
			int indexOfHighest = 0;
			int count = 0;
			for(Creature buddy : list)
			{
				if(list.get(indexOfHighest).getDEX()<buddy.getDEX())
				{
					indexOfHighest = count;
				}
				count++;
			}
			rList[iterator]=list.get(indexOfHighest);
			list.remove(indexOfHighest);
			iterator++;
		}
		return rList;
		
		
	}
	
	public void scrollRight()
	{
		//loop through each row/column
		int x=0;
		int y=0;
		while(y<21)
		{
			//set to next image
			while(x!=20)
			{
				world[x][y] = world[x+1][y];
				x=x+1;
			}
			//last column needs to be pulled from worldview
			int wvx = world[x][y].getX();
			int wvy = world[x][y].getY();
			
			world[x][y]=worldView[wvx+1][wvy];
			x=0;
			y++;
		}
		//redraw
		repaint();

	}
	
	public TileNode getNode(Dimension xy)
	{
		return worldView[xy.width][xy.height];
	}
	
	public void setNode(Dimension xy, TileNode t)
	{
		worldView[xy.width][xy.height]= t;
		repaint();
	}
	
	public void scrollLeft()
	{
		//loop through each row/column
		int x=20;
		int y=0;
		while(y<21)
		{
			//set to next image
			while(x!=0)
			{
				world[x][y] = world[x-1][y];
				x=x-1;
			}
			int wvx = world[x][y].getX();
			int wvy = world[x][y].getY();
			
			world[x][y]=worldView[wvx-1][wvy];
			x=20;
			y++;
		}
		//redraw
		repaint();
		
	}
	
	public void scrollUp()
	{
		//loop through each row/column
		int x=0;
		int y=20;
		while(x<21)
		{
			//set to next image
			while(y!=0)
			{
				world[x][y] = world[x][y-1];
				y=y-1;
			}
			int wvx = world[x][y].getX();
			int wvy = world[x][y].getY();
			
			world[x][y]=worldView[wvx][wvy-1];
			y=20;
			x++;
		}
		//redraw
		repaint();
	}
	
	public void scrollDown()
	{
		//loop through each row/column
		int x=0;
		int y=0;
		while(x<21)
		{
			//set to next image
			while(y!=20)
			{
				world[x][y] = world[x][y+1];
				y=y+1;
			}
			int wvx = world[x][y].getX();
			int wvy = world[x][y].getY();
			
			world[x][y]=worldView[wvx][wvy+1];
			y=0;
			x++;
		}
		//redraw
		repaint();
	}

	public Player getPlayer()
	{
		return p;
	}


}
