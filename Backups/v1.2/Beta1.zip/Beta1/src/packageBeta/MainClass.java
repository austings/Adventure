package packageBeta;

import menu.Screen;

public class MainClass 
{
	public void start()
	{
		Screen s = new Screen();
		
	}
	
	public static void main(String[] args)
	{
		MainClass c = new MainClass();
		c.start();
	}
}
