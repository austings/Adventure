package packageBeta;

import java.util.UUID;

public class TileThing 
{
	private String name;
	private String callNum;
	private int weight =0;
	private int id = -25;
	
	public TileThing(String name)
	{
		this.name = name;
		callNum = UUID.randomUUID().toString();
	}
	public TileThing(String name, int id)
	{
		this.name = name;
		callNum = UUID.randomUUID().toString();
		this.id = id;
	}
	
	public int getImageID()
	{
		return id;
	}
	
	public void setImageID(int id)
	{
		this.id = id;
	}
	
	public String getName()
	{
		return name;
	}
	
	public String getCallNum()
	{
		return callNum;
	}
	
	public void setName(String name)
	{
		this.name =name;
	}
	
	public void setWeight(int s)
	{
		weight = s;
	}
	
	public int getWeight()
	{
		return weight;
	}
}
