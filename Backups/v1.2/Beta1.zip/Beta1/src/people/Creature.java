package people;

import java.awt.Dimension;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Random;

import packageBeta.TileNode;
import packageBeta.TileThing;

public class Creature extends TileThing implements Runnable
{
	private int STR;
	private int INT;
	private int DEX;
	private int x;
	private int y;
	private String lastLookedDirection="up";
	
	private boolean walking = false;
	private Dimension destination;
	private Queue<TileNode> path = new LinkedList<TileNode>();
	private boolean closed[][];
	private TileNode[][] world;
	
	public Creature(String name,Dimension d, int id)
	{
		super(name,id);
		super.setWeight(150);
		STR = 5;
		INT = 5;
		DEX = 5;
		x=d.width;
		y=d.height;
		
	}
	
	public Dimension getPosition()
	{
		return new Dimension(x,y);
	}
	
	public String getName()
	{
		return super.getName();
	}
	
	public void moveRight()
	{
		lastLookedDirection="right";
		x++;
	}
	
	public void moveLeft()
	{
		lastLookedDirection="left";
		x=x-1;
	}
	
	public void moveUp()
	{
		lastLookedDirection="up";
		y=y-1;
	}
	
	public void moveDown()
	{
		lastLookedDirection="down";
		y++;
	}
	
	public int getSTR()
	{
		return STR;
	}
	
	public void addSTR(int i)
	{
		STR = STR+i;
	}
	
	public int getINT()
	{
		return INT;
	}
	
	public void addINT(int i)
	{
		INT = INT+i;
	}
	
	public int getDEX()
	{
		return DEX;
	}
	
	public void addDEX(int i)
	{
		DEX = DEX+i;
	}
	
	private String getLastLookedDirection()
	{
		return lastLookedDirection;
	}
	
	//Returns the view around a creature, so that
	//it can make a decision.
	public TileNode[][] getWorld(TileNode[][] worldV)
	{
		TileNode[][] world = new TileNode[21][21];
		
		//this is the x and y coordinates of the top left position
		//the creature can see. On a 100x100 grid this is position 40
		int xC = (x)-10;//40 on 100x100
		int yC = (y)-10;//40 on 100x100
		int worldx=0;
		int worldy=0;
		//
		for(int i = xC;worldx!=21;i++)
		{
			for(int j = yC; worldy!=21;j++)
			{

				//creates a blank world
				TileNode n = worldV[i][j];
				world[worldx][worldy] = n;
				worldy++;
			}
			worldy = 0;
			worldx++;
		}
		return world;
		
	}
	
	public void runTurn()
	{
		//script for selecting a random tile in the world and moving to it.
		if(walking==false)
		{
			Random r = new Random();
			
			int posX;
			int posY;
			
			do{
			posX = r.nextInt(world.length-1)+1;
			posY = r.nextInt(world[1].length-1)+1;
			}
			while(!(world[posX][posY].isSolid()));
			destination = new Dimension(posX,posY);
			//int heuristicCost = C
			
			closed = new boolean[world.length][world[1].length];
			path.add(world[x][y]);
			
			while(true)
			{
				TileNode current= path.poll();
				closed[current.getX()][current.getY()]=true;
				if(new Dimension(current.getX(),current.getY())
					.equals(destination))
				{
					return;
				}
				
				TileNode t;
				if(current.getX()-1>=0)
				{
					
				}

				//if we could move right and we needed to, we did.
				
			}
			
		}
		//test moving up
			int dx = destination.width - x;//x1-x2
			int dy = destination.height - y;//y1-y2
	}
	
	public void setWorldInstance(TileNode[][] world)
	{
		
	}

	public void run() 
	{
		runTurn();
		
	}

	
	
}
