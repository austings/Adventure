package people;

import java.awt.Dimension;

public class Player extends Creature
{
	public Player(String name, Dimension d)
	{
		super(name,d,1);
	}

}
