package tools;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.imageio.ImageIO;

public class ImageLibrary 
{
    private Map<Integer, BufferedImage> b;
	
    /*
     * Negative values are not solid objects.
     * Image Codes
     * -20 Open Door
     * -1 through -9 Grass
     * 0  Blank Tile
     * 1  Player Tile
     * 2  Wall1A; brown wall LR
     * 3  Wall1B; brown wall UD
     * 4  Wall1C; full brown 
     * 20 Door
     */
	
	public ImageLibrary()
	{
		//create new hashmap
		b = new HashMap<Integer,BufferedImage>();
		
		try {
			//load images for tiles
			BufferedImage player = ImageIO.read(getClass().getResourceAsStream("/tiles/player.png"));
			BufferedImage wall1a = ImageIO.read(getClass().getResourceAsStream("/tiles/wall1a.png"));
			BufferedImage wall1b = ImageIO.read(getClass().getResourceAsStream("/tiles/wall1b.png"));
			BufferedImage wall1c = ImageIO.read(getClass().getResourceAsStream("/tiles/wall1c.png"));
			BufferedImage green = ImageIO.read(getClass().getResourceAsStream("/tiles/grassM.png"));
			BufferedImage greenT = ImageIO.read(getClass().getResourceAsStream("/tiles/grassT.png"));
			BufferedImage greenB = ImageIO.read(getClass().getResourceAsStream("/tiles/grassB.png"));
			BufferedImage greenBL = ImageIO.read(getClass().getResourceAsStream("/tiles/grassBL.png"));
			BufferedImage greenBR = ImageIO.read(getClass().getResourceAsStream("/tiles/grassBR.png"));
			BufferedImage greenTR = ImageIO.read(getClass().getResourceAsStream("/tiles/grassTR.png"));
			BufferedImage greenTL = ImageIO.read(getClass().getResourceAsStream("/tiles/grassTL.png"));
			BufferedImage greenL = ImageIO.read(getClass().getResourceAsStream("/tiles/grassL.png"));
			BufferedImage greenR = ImageIO.read(getClass().getResourceAsStream("/tiles/grassR.png"));
			BufferedImage none = ImageIO.read(getClass().getResourceAsStream("/tiles/none.png"));
			BufferedImage elf = ImageIO.read(getClass().getResourceAsStream("/tiles/elf.png"));
			BufferedImage princess = ImageIO.read(getClass().getResourceAsStream("/tiles/princess.png"));
			BufferedImage fireball = ImageIO.read(getClass().getResourceAsStream("/tiles/fireball.png"));
			BufferedImage door1 = ImageIO.read(getClass().getResourceAsStream("/tiles/door.png"));
			BufferedImage door1O = ImageIO.read(getClass().getResourceAsStream("/tiles/dooropen.png"));
			BufferedImage bag = ImageIO.read(getClass().getResourceAsStream("/images/bpack.png"));
			BufferedImage chest = ImageIO.read(getClass().getResourceAsStream("/tiles/chest2.png"));
			
			b.put(1, player);
			b.put(2, wall1a);
			b.put(3, wall1b);
			b.put(4, wall1c);
			b.put(20, door1);
			b.put(1000, elf);
			b.put(1001, princess);
			b.put(0, none);
			b.put(-1, green);
			b.put(-2, greenT);
			b.put(-3, greenTR);
			b.put(-4, greenTL);
			b.put(-5, greenB);
			b.put(-6, greenBL);
			b.put(-7, greenBR);
			b.put(-8, greenR);
			b.put(-9, greenL);
			b.put(-20,door1O);
			b.put(-25,chest);
			b.put(-200, fireball);
			b.put(-999,bag);
		} catch (IOException e) {
			e.printStackTrace();
		}
		//associate term with each tile
	}
	
	public BufferedImage get(int s)
	{
		return b.get(s);
	}
}
