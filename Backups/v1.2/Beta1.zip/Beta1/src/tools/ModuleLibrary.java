package tools;

import java.awt.Dimension;

import packageBeta.TileNode;

public class ModuleLibrary 
{
	//sets what current module to use
	private int currentModuleID = 0;
	
	
	//higher numbers mean more modules
	private final int moduleDensity = 10;
	//affects how dense modules spawn
	
	
	public ModuleLibrary()
	{
		
	}
	
	public int getDensity()
	{
		return moduleDensity;
	}
	
	public ModuleLibrary(int s)
	{
		currentModuleID = s;
	}
	
	public void setModule(int s)
	{
		currentModuleID = s;
	}
	
	public Dimension getModuleSize()
	{
		switch(currentModuleID)
		{
		case 0:
			return new Dimension(10,10);
		case 1:
			return new Dimension(15,15);
		default:
			return new Dimension(10,10);
		}
	}
	
	public TileNode[][] paintLargeHouse(TileNode[][] worldView, int resultx, int resulty)
	{
		//paint stuff
				//top wall
				worldView[resultx+1][resulty+1].setImage(2);
				worldView[resultx+2][resulty+1].setImage(2);
				worldView[resultx+3][resulty+1].setImage(2);
				worldView[resultx+4][resulty+1].setImage(2);
				worldView[resultx+5][resulty+1].setImage(2);
				worldView[resultx+6][resulty+1].setImage(2);
				worldView[resultx+7][resulty+1].setImage(2);
				worldView[resultx+8][resulty+1].setImage(4);
				worldView[resultx+8][resulty+2].setImage(3);
				worldView[resultx+8][resulty+2].setImage(4);
				worldView[resultx+9][resulty+2].setImage(2);
				worldView[resultx+10][resulty+2].setImage(2);
				worldView[resultx+11][resulty+2].setImage(2);
				worldView[resultx+12][resulty+2].setImage(4);
				
				//side walls
				worldView[resultx][resulty+1].setImage(4);
				worldView[resultx][resulty+2].setImage(3);
				worldView[resultx][resulty+3].setImage(3);
				worldView[resultx][resulty+4].setImage(3);
				worldView[resultx][resulty+5].setImage(3);
				worldView[resultx][resulty+6].setImage(3);
				worldView[resultx][resulty+7].setImage(3);
				worldView[resultx][resulty+8].setImage(3);
				worldView[resultx][resulty+9].setImage(3);
				worldView[resultx][resulty+10].setImage(4);
				
				
				worldView[resultx+12][resulty+3].setImage(3);
				worldView[resultx+12][resulty+4].setImage(3);
				worldView[resultx+12][resulty+5].setImage(20);
				worldView[resultx+12][resulty+6].setImage(3);
				worldView[resultx+12][resulty+7].setImage(3);
				worldView[resultx+12][resulty+8].setImage(3);
				
				//bottom wall

				worldView[resultx+1][resulty+10].setImage(2);
				worldView[resultx+2][resulty+10].setImage(2);
				worldView[resultx+3][resulty+10].setImage(2);
				worldView[resultx+4][resulty+10].setImage(2);
				worldView[resultx+5][resulty+10].setImage(2);
				worldView[resultx+6][resulty+10].setImage(2);
				worldView[resultx+7][resulty+10].setImage(2);
				worldView[resultx+8][resulty+10].setImage(4);
				worldView[resultx+8][resulty+9].setImage(3);
				worldView[resultx+8][resulty+9].setImage(3);
				worldView[resultx+8][resulty+9].setImage(4);
				worldView[resultx+9][resulty+9].setImage(2);
				worldView[resultx+10][resulty+9].setImage(2);
				worldView[resultx+11][resulty+9].setImage(2);
				worldView[resultx+12][resulty+9].setImage(4);
				
				return worldView;
	}
	
	
	public TileNode[][] paintHouse(TileNode[][] worldView, int resultx, int resulty)
	{
		//paint stuff
		//top wall
		worldView[resultx+1][resulty+1].setImage(2);
		worldView[resultx+2][resulty+1].setImage(2);
		worldView[resultx+3][resulty+1].setImage(2);
		worldView[resultx+4][resulty+1].setImage(2);
		worldView[resultx+5][resulty+1].setImage(2);
		worldView[resultx+6][resulty+1].setImage(2);
		worldView[resultx+7][resulty+1].setImage(2);
		
		//side walls
		worldView[resultx][resulty+1].setImage(4);
		worldView[resultx][resulty+2].setImage(3);
		worldView[resultx][resulty+3].setImage(3);
		worldView[resultx][resulty+4].setImage(3);
		worldView[resultx][resulty+5].setImage(3);
		worldView[resultx][resulty+6].setImage(4);
		
		worldView[resultx+8][resulty+1].setImage(4);
		worldView[resultx+8][resulty+2].setImage(3);
		worldView[resultx+8][resulty+3].setImage(3);
		worldView[resultx+8][resulty+4].setImage(3);
		worldView[resultx+8][resulty+5].setImage(3);
		worldView[resultx+8][resulty+6].setImage(4);
		
		//bottom wall
		worldView[resultx+1][resulty+6].setImage(2);
		worldView[resultx+2][resulty+6].setImage(2);
		worldView[resultx+3][resulty+6].setImage(2);
		worldView[resultx+4][resulty+6].setImage(20);
		worldView[resultx+5][resulty+6].setImage(2);
		worldView[resultx+6][resulty+6].setImage(2);
		worldView[resultx+7][resulty+6].setImage(2);
		return worldView;
	}
	
	public TileNode[][] returnAddedModule(TileNode[][] worldView,int resultx, int resulty)
	{
		
		switch(currentModuleID)
		{
		case 0:
			return paintHouse(worldView, resultx, resulty);
		case 1:
			return paintLargeHouse(worldView, resultx, resulty);
		default:
			return paintHouse(worldView, resultx, resulty);
		}
		
	}
}
