package tools;

public class Spell
{
	private int intensity;
	private int radius;
	private String name;
	private int ImageID;
	
	public Spell(String name, int ImageID)
	{
		this.name = name;
		this.ImageID = ImageID;
	}
}
