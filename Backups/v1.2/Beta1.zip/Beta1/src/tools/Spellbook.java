package tools;

import java.util.ArrayList;

import packageBeta.TileNode;

/*
 * Class for drawing spells
 */
public class Spellbook 
{
	private ArrayList<Spell> book = new ArrayList<Spell>();
	private TileNode[][]worldView = null;
	private String owner = "";
	
	/*
	 * Collection of spells for each character
	 */
	public Spellbook(String owner)
	{
		this.owner = owner;
		if(owner=="Player")
		{
			book.add(new Spell("Fireball",-200));
		}
	}
}
