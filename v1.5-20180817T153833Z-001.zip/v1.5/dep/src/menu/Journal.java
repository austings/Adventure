package menu;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;

import tools.ImageLibrary;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.JSplitPane;
import java.awt.CardLayout;
import javax.swing.JTextPane;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.FlowLayout;
import javax.swing.JList;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;
import java.awt.GridLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.Color;
import java.awt.Font;

public class Journal extends JDialog
{
	private ImageLibrary il = new ImageLibrary();
	public Journal(JFrame parentFrame, String frameTitle, boolean tf)
	{
		super(parentFrame,frameTitle,tf);
		this.setSize(new Dimension(1280, 800));
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		
		
		JPanel north = new JPanel();
		getContentPane().add(north, BorderLayout.NORTH);
		north.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		JButton btnNewButton_4 = new JButton("Quests");
		north.add(btnNewButton_4);
		btnNewButton_4.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		JButton button = new JButton("Characters");
		north.add(button);
		button.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		JButton btnLocations = new JButton("Locations");
		north.add(btnLocations);
		btnLocations.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		JButton btnItems = new JButton("Items\r\n");
		north.add(btnItems);
		btnItems.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		JButton btnCreatures = new JButton("Creatures\r\n");
		north.add(btnCreatures);
		btnCreatures.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		JButton btnMisc = new JButton("Misc\r\n");
		north.add(btnMisc);
		btnMisc.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		JPanel panel = new JPanel();
		getContentPane().add(panel, BorderLayout.CENTER);
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWidths = new int[]{288, 637, 0};
		gbl_panel.rowHeights = new int[]{730, 0};
		gbl_panel.columnWeights = new double[]{0.0, 1.0, Double.MIN_VALUE};
		gbl_panel.rowWeights = new double[]{0.0, Double.MIN_VALUE};
		panel.setLayout(gbl_panel);
		
		
		
		JPanel west = new JPanel();
		GridBagConstraints gbc_west = new GridBagConstraints();
		gbc_west.fill = GridBagConstraints.BOTH;
		gbc_west.insets = new Insets(0, 0, 0, 5);
		gbc_west.gridx = 0;
		gbc_west.gridy = 0;
		panel.add(west, gbc_west);
		
		JPanel panel_6 = new JPanel();
		west.add(panel_6);
		panel_6.setLayout(new GridLayout(10, 1, 0, 0));
		
		JLabel lblNewLabel_1 = new JLabel("Entries\r\n");
		lblNewLabel_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 30));
		panel_6.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("New button");
		panel_6.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("New button");
		panel_6.add(btnNewButton_1);
		
		JPanel east = new JPanel();
		GridBagConstraints gbc_east = new GridBagConstraints();
		gbc_east.fill = GridBagConstraints.BOTH;
		gbc_east.gridx = 1;
		gbc_east.gridy = 0;
		panel.add(east, gbc_east);
		east.setLayout(new CardLayout(0, 0));
		
		JPanel Entry = new JPanel();
		east.add(Entry, "name_386922956291151");
		Entry.setLayout(new BorderLayout(0, 0));
		
		JLabel lblNewLabel = new JLabel("Entry");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Gabriola", Font.PLAIN, 30));
		Entry.add(lblNewLabel, BorderLayout.NORTH);
		
		JTextPane textPane = new JTextPane();
		textPane.setFont(new Font("Gabriola", Font.PLAIN, 30));
		textPane.setForeground(new Color(250, 235, 215));
		Entry.add(textPane, BorderLayout.CENTER);
		
		
		
	}
	/**
	public class JPanelB extends JPanel {

		  private Image backgroundImage;
		  
		  public JPanelB(int id)
		  {
			  super();
			  backgroundImage = il.get(id);
		  }

		  public void paintComponent(Graphics g) 
		  {
		    super.paintComponent(g);
		    g.drawImage(backgroundImage, 0, 0, this);
		  }
		  
		}
		*/
}
