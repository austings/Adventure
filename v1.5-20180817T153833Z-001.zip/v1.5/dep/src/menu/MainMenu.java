package menu;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.WindowConstants;

import tools.FontLibrary;
import tools.ImageLibrary;
import tools.Jukebox;

import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JTextPane;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GraphicsEnvironment;

import javax.sound.sampled.AudioInputStream;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

public class MainMenu extends JFrame
{
	PaintPane center;
	ImageLibrary il;
	
	public MainMenu()
	{
		super();
		Jukebox jukebox = new Jukebox();
		FontLibrary fl = new FontLibrary();
		il = new ImageLibrary();
		
		this.setBackground(Color.black);
		//this.setExtendedState(JFrame.MAXIMIZED_BOTH); 
		//this.setUndecorated(true);
		this.setSize(new Dimension(800,800));
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		
		JPanel Master = new JPanel();
		getContentPane().add(Master, BorderLayout.CENTER);
		Master.setLayout(new BorderLayout(0, 0));
		
		center = new PaintPane(il.get(-997));
		FlowLayout flowLayout = (FlowLayout) center.getLayout();
		flowLayout.setVgap(500);
		flowLayout.setHgap(50);
		center.setBackground(Color.BLACK);
		Master.add(center, BorderLayout.CENTER);
		
		JButton btnNewButton = new JButton("Start New Game");
		btnNewButton.setFont(fl.getFont("medReg"));
		(btnNewButton).addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				NewCharacter s = new NewCharacter(fl, il);
				dispose();
			}
		}
		);
		center.add(btnNewButton);

		
		JPanel panel = new JPanel();
		panel.setBackground(Color.BLACK);
		Master.add(panel, BorderLayout.NORTH);
		
		JTextPane title = new JTextPane();
		GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
		title.setFont(fl.getFont("medReg36"));
		title.setForeground(Color.WHITE);
		title.setBackground(Color.BLACK);
		title.setText("Deremor");
		title.setEditable(false);
		panel.add(title);
		this.setVisible(true);
	}
	


}
