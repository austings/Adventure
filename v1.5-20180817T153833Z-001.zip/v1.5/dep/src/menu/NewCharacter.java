package menu;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
import javax.swing.JLabel;
import java.awt.CardLayout;
import javax.swing.SwingConstants;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.Font;

import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.AbstractListModel;

import tools.FontLibrary;
import tools.ImageLibrary;
import tools.ListColorer;
import java.awt.ScrollPane;
import javax.swing.JTextArea;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class NewCharacter extends JFrame implements ActionListener
{
	private JTextField nameField;
	
	private JPanel Center;
	
	private JButton btnNextPage;
	private JButton btnNextPage_1;
	private JButton btnNextPage_2;
	private JButton btnFinalize;
	private JButton btnLastPage;
	private JButton btnLastPage_1;
	private JButton btnLastPage_2;
	
	private FontLibrary fl;
	private ImageLibrary il;
	
	public NewCharacter(FontLibrary fl, ImageLibrary il)
	{
		super();
		this.fl = fl;
		this.il = il;
		this.setBackground(Color.black);
		//this.setExtendedState(JFrame.MAXIMIZED_BOTH); 
		//this.setUndecorated(true);
		this.setSize(new Dimension(800,800));
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		
		JPanel Master = new JPanel();
		Master.setBackground(Color.WHITE);
		getContentPane().add(Master, BorderLayout.CENTER);
		Master.setLayout(new BorderLayout(0, 0));
		
		Center = new JPanel();
		Center.setBackground(Color.WHITE);
		Master.add(Center, BorderLayout.CENTER);
		Center.setLayout(new CardLayout(0, 0));
		
		JPanel raceAndClass = new JPanel();
		Center.add(raceAndClass, "name_1598053474146027");
		GridBagLayout gridBagLayout_1 = new GridBagLayout();
		gridBagLayout_1.columnWidths = new int[]{0, 500, 301, 500, 0};
		gridBagLayout_1.rowHeights = new int[]{80, 0, 61, 0, 0, 0, 91, 117, 0, 0};
		gridBagLayout_1.columnWeights = new double[]{0.0, 1.0, 0.0, 1.0, Double.MIN_VALUE};
		gridBagLayout_1.rowWeights = new double[]{0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		raceAndClass.setLayout(gridBagLayout_1);
		
		JLabel lblName = new JLabel("Name");
		GridBagConstraints gbc_lblName = new GridBagConstraints();
		gbc_lblName.insets = new Insets(0, 0, 5, 5);
		gbc_lblName.gridx = 2;
		gbc_lblName.gridy = 1;
		raceAndClass.add(lblName, gbc_lblName);
		
		nameField = new JTextField();
		GridBagConstraints gbc_nameField = new GridBagConstraints();
		gbc_nameField.anchor = GridBagConstraints.NORTH;
		gbc_nameField.insets = new Insets(0, 0, 5, 5);
		gbc_nameField.fill = GridBagConstraints.HORIZONTAL;
		gbc_nameField.gridx = 2;
		gbc_nameField.gridy = 2;
		raceAndClass.add(nameField, gbc_nameField);
		nameField.setColumns(10);
		
		JPanel racePanel = new JPanel();
		GridBagConstraints gbc_racePanel = new GridBagConstraints();
		gbc_racePanel.insets = new Insets(0, 0, 5, 5);
		gbc_racePanel.fill = GridBagConstraints.BOTH;
		gbc_racePanel.gridx = 1;
		gbc_racePanel.gridy = 3;
		raceAndClass.add(racePanel, gbc_racePanel);
		
		JPanel jobPanel = new JPanel();
		GridBagConstraints gbc_jobPanel = new GridBagConstraints();
		gbc_jobPanel.insets = new Insets(0, 0, 5, 0);
		gbc_jobPanel.fill = GridBagConstraints.BOTH;
		gbc_jobPanel.gridx = 3;
		gbc_jobPanel.gridy = 3;
		raceAndClass.add(jobPanel, gbc_jobPanel);
		
		JLabel lblRace_1 = new JLabel("Race");
		GridBagConstraints gbc_lblRace_1 = new GridBagConstraints();
		gbc_lblRace_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblRace_1.gridx = 1;
		gbc_lblRace_1.gridy = 4;
		raceAndClass.add(lblRace_1, gbc_lblRace_1);
		
		JLabel lblClass_1 = new JLabel("Job");
		GridBagConstraints gbc_lblClass_1 = new GridBagConstraints();
		gbc_lblClass_1.insets = new Insets(0, 0, 5, 0);
		gbc_lblClass_1.gridx = 3;
		gbc_lblClass_1.gridy = 4;
		raceAndClass.add(lblClass_1, gbc_lblClass_1);
		
		JComboBox raceBox = new JComboBox();
		raceBox.setModel(new DefaultComboBoxModel(new String[] {"Human", "Dwarf", "Dryad", "Goblin", "Satyr", "Reptillian"}));
		GridBagConstraints gbc_raceBox = new GridBagConstraints();
		gbc_raceBox.insets = new Insets(0, 0, 5, 5);
		gbc_raceBox.fill = GridBagConstraints.HORIZONTAL;
		gbc_raceBox.gridx = 1;
		gbc_raceBox.gridy = 5;
		raceAndClass.add(raceBox, gbc_raceBox);
		
		JComboBox jobBox = new JComboBox();
		jobBox.setModel(new DefaultComboBoxModel(new String[] {"Vagabond", "Farmer", "Merchant", "Blacksmith", "Doctor", "Teacher", "Noble", "Guard", "Bartender", "Scribe"}));
		jobBox.setEditable(true);
		GridBagConstraints gbc_jobBox = new GridBagConstraints();
		gbc_jobBox.insets = new Insets(0, 0, 5, 0);
		gbc_jobBox.fill = GridBagConstraints.HORIZONTAL;
		gbc_jobBox.gridx = 3;
		gbc_jobBox.gridy = 5;
		raceAndClass.add(jobBox, gbc_jobBox);
		
		btnNextPage = new JButton("Next Page");
		btnNextPage.addActionListener(this);
		
		GridBagConstraints gbc_btnNextPage = new GridBagConstraints();
		gbc_btnNextPage.insets = new Insets(0, 0, 5, 0);
		gbc_btnNextPage.gridx = 3;
		gbc_btnNextPage.gridy = 7;
		raceAndClass.add(btnNextPage, gbc_btnNextPage);
		
		JPanel characteristics = new JPanel();
		Center.add(characteristics, "name_1598055699063812");
		GridBagLayout gbl_characteristics = new GridBagLayout();
		gbl_characteristics.columnWidths = new int[]{0, 0, 0, 0, 0, 0};
		gbl_characteristics.rowHeights = new int[]{50, 100, 575, 150, 54, 51, 46, 0};
		gbl_characteristics.columnWeights = new double[]{1.0, 1.0, 1.0, 1.0, 0.0, Double.MIN_VALUE};
		gbl_characteristics.rowWeights = new double[]{0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		characteristics.setLayout(gbl_characteristics);
		
		JLabel lblCharacteristics = new JLabel("Characteristics");
		lblCharacteristics.setFont(new Font("Verdana", Font.BOLD, 20));
		GridBagConstraints gbc_lblCharacteristics = new GridBagConstraints();
		gbc_lblCharacteristics.insets = new Insets(0, 0, 5, 5);
		gbc_lblCharacteristics.gridx = 1;
		gbc_lblCharacteristics.gridy = 1;
		characteristics.add(lblCharacteristics, gbc_lblCharacteristics);
		
		JPanel panel = new JPanel();
		FlowLayout flowLayout_1 = (FlowLayout) panel.getLayout();
		flowLayout_1.setVgap(50);
		GridBagConstraints gbc_panel = new GridBagConstraints();
		gbc_panel.insets = new Insets(0, 0, 5, 5);
		gbc_panel.fill = GridBagConstraints.BOTH;
		gbc_panel.gridx = 3;
		gbc_panel.gridy = 1;
		characteristics.add(panel, gbc_panel);
		
		JLabel lblPointsAvailable = new JLabel("Points Available:");
		lblPointsAvailable.setFont(new Font("Verdana", Font.BOLD, 20));
		panel.add(lblPointsAvailable);
		
		JLabel label = new JLabel("0");
		label.setFont(new Font("Verdana", Font.BOLD, 20));
		panel.add(label);
		
		JScrollPane scrollPane = new JScrollPane();
		JList cList = new JList();
		cList.setCellRenderer(new ListColorer(20));
		cList.setFont(new Font("Verdana", Font.BOLD, 25));
		cList.setModel(new AbstractListModel() {
			String[] values = new String[] {"Strong (50)", "Genius (50)", "Quick (40)", "Rich (40)", "Pack Mule (30)", "Tough (30)", "Charming (30)", "Intimidating (30)", "Seductive (30)", "Photographic Memory (25)", "Lucky (20)", "Sneaky (20)", "Attentive (20)", "Cannibal (20)", "Ambidextrous (15)", "Attractive (10)", "Psychopathic (10)", "Tall (5)", "High Metabolism (5)", "Light Sleeper (5)", "Homosexual (0)", "Short (-5)", "Deep Sleeper (-5)", "Bad Vision (-5)", "Ugly (-10)", "Depressed (-10)", "Ignorant (-20)", "High Tolerance (-20)", "Poor (-20)", "Deaf (-25)", "Slow (-30)", "Vegan (-30)", "Weak (-40)", "Blind (-40)", "Amputee (-50)", "Imbicile (-50)"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		GridBagConstraints gbc_cList = new GridBagConstraints();
		gbc_cList.insets = new Insets(0, 0, 5, 5);
		gbc_cList.fill = GridBagConstraints.BOTH;
		gbc_cList.gridx = 1;
		gbc_cList.gridy = 2;
		scrollPane.setViewportView(cList);
		characteristics.add(scrollPane, gbc_cList);
		
		JScrollPane scrollPane2 = new JScrollPane();
		JList cList2 = new JList();
		GridBagConstraints gbc_cList2 = new GridBagConstraints();
		gbc_cList2.insets = new Insets(0, 0, 5, 5);
		gbc_cList2.fill = GridBagConstraints.BOTH;
		gbc_cList2.gridx = 3;
		gbc_cList2.gridy = 2;
		scrollPane2.setViewportView(cList2);
		characteristics.add(scrollPane2, gbc_cList2);
		
		JTextArea textArea = new JTextArea();
		GridBagConstraints gbc_textArea = new GridBagConstraints();
		gbc_textArea.insets = new Insets(0, 0, 5, 5);
		gbc_textArea.fill = GridBagConstraints.BOTH;
		gbc_textArea.gridx = 1;
		gbc_textArea.gridy = 3;
		characteristics.add(textArea, gbc_textArea);
		
		btnLastPage = new JButton("Last Page");
		btnLastPage.addActionListener(this);
		GridBagConstraints gbc_btnLastPage = new GridBagConstraints();
		gbc_btnLastPage.insets = new Insets(0, 0, 5, 5);
		gbc_btnLastPage.gridx = 1;
		gbc_btnLastPage.gridy = 5;
		characteristics.add(btnLastPage, gbc_btnLastPage);
		
		btnNextPage_1 = new JButton("Next Page");
		btnNextPage_1.addActionListener(this);
		GridBagConstraints gbc_btnNextPage_1 = new GridBagConstraints();
		gbc_btnNextPage_1.insets = new Insets(0, 0, 5, 5);
		gbc_btnNextPage_1.gridx = 3;
		gbc_btnNextPage_1.gridy = 5;
		characteristics.add(btnNextPage_1, gbc_btnNextPage_1);
		
		JPanel skills = new JPanel();
		Center.add(skills, "name_1598059396940304");
		GridBagLayout gbl_skills = new GridBagLayout();
		gbl_skills.columnWidths = new int[] {0, 0, 0, 0, 0, 2};
		gbl_skills.rowHeights = new int[] {0, 0, 0, 0, 46, 2};
		gbl_skills.columnWeights = new double[]{0.0, 1.0, 1.0, 1.0, 0.0, Double.MIN_VALUE};
		gbl_skills.rowWeights = new double[]{0.0, 0.0, 1.0, 0.0, 0.0, Double.MIN_VALUE};
		skills.setLayout(gbl_skills);
		
		JPanel panel_1 = new JPanel();
		GridBagConstraints gbc_panel_1 = new GridBagConstraints();
		gbc_panel_1.insets = new Insets(0, 0, 5, 5);
		gbc_panel_1.fill = GridBagConstraints.BOTH;
		gbc_panel_1.gridx = 2;
		gbc_panel_1.gridy = 2;
		skills.add(panel_1, gbc_panel_1);
		
		btnLastPage_1 = new JButton("Last Page");
		btnLastPage_1.addActionListener(this);
		GridBagConstraints gbc_btnLastPage_1 = new GridBagConstraints();
		gbc_btnLastPage_1.insets = new Insets(0, 0, 5, 5);
		gbc_btnLastPage_1.gridx = 1;
		gbc_btnLastPage_1.gridy = 3;
		skills.add(btnLastPage_1, gbc_btnLastPage_1);
		
		btnNextPage_2 = new JButton("Next Page");
		btnNextPage_2.addActionListener(this);
		GridBagConstraints gbc_btnNextPage_2 = new GridBagConstraints();
		gbc_btnNextPage_2.insets = new Insets(0, 0, 5, 5);
		gbc_btnNextPage_2.gridx = 3;
		gbc_btnNextPage_2.gridy = 3;
		skills.add(btnNextPage_2, gbc_btnNextPage_2);
		
		JPanel ability = new JPanel();
		Center.add(ability, "name_1598126545981979");
		GridBagLayout gbl_ability = new GridBagLayout();
		gbl_ability.columnWidths = new int[]{0, 0, 0, 0, 0, 0};
		gbl_ability.rowHeights = new int[]{0, 0, 0, 0, 46, 0};
		gbl_ability.columnWeights = new double[]{0.0, 1.0, 1.0, 1.0, 0.0, Double.MIN_VALUE};
		gbl_ability.rowWeights = new double[]{0.0, 0.0, 1.0, 0.0, 0.0, Double.MIN_VALUE};
		ability.setLayout(gbl_ability);
		
		JPanel panel_2 = new JPanel();
		GridBagConstraints gbc_panel_2 = new GridBagConstraints();
		gbc_panel_2.insets = new Insets(0, 0, 5, 5);
		gbc_panel_2.fill = GridBagConstraints.BOTH;
		gbc_panel_2.gridx = 2;
		gbc_panel_2.gridy = 2;
		ability.add(panel_2, gbc_panel_2);
		
		btnLastPage_2 = new JButton("Last Page");
		btnLastPage_2.addActionListener(this);
		GridBagConstraints gbc_btnLastPage_2 = new GridBagConstraints();
		gbc_btnLastPage_2.insets = new Insets(0, 0, 5, 5);
		gbc_btnLastPage_2.gridx = 1;
		gbc_btnLastPage_2.gridy = 3;
		ability.add(btnLastPage_2, gbc_btnLastPage_2);
		
		btnFinalize = new JButton("Finalize");
		btnFinalize.addActionListener(this);
		GridBagConstraints gbc_btnFinalize = new GridBagConstraints();
		gbc_btnFinalize.insets = new Insets(0, 0, 5, 5);
		gbc_btnFinalize.gridx = 3;
		gbc_btnFinalize.gridy = 3;
		ability.add(btnFinalize, gbc_btnFinalize);
		
		JPanel summary = new JPanel();
		Master.add(summary, BorderLayout.EAST);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{0, 0, 0, 56, 0};
		gridBagLayout.rowHeights = new int[]{16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gridBagLayout.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		summary.setLayout(gridBagLayout);
		
		JLabel lblNewLabel_2 = new JLabel("New label");
		GridBagConstraints gbc_lblNewLabel_2 = new GridBagConstraints();
		gbc_lblNewLabel_2.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_2.gridx = 0;
		gbc_lblNewLabel_2.gridy = 0;
		summary.add(lblNewLabel_2, gbc_lblNewLabel_2);
		
		JLabel lblNewLabel_1 = new JLabel("Name:");
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.insets = new Insets(0, 0, 5, 5);
		gbc.anchor = GridBagConstraints.NORTHWEST;
		gbc.gridx = 1;
		gbc.gridy = 2;
		summary.add(lblNewLabel_1, gbc);
		
		JLabel lblRace = new JLabel("Race:");
		GridBagConstraints gbc_lblRace = new GridBagConstraints();
		gbc_lblRace.insets = new Insets(0, 0, 5, 5);
		gbc_lblRace.gridx = 1;
		gbc_lblRace.gridy = 3;
		summary.add(lblRace, gbc_lblRace);
		
		JLabel lblClass = new JLabel("Job:");
		GridBagConstraints gbc_lblClass = new GridBagConstraints();
		gbc_lblClass.insets = new Insets(0, 0, 5, 5);
		gbc_lblClass.gridx = 1;
		gbc_lblClass.gridy = 4;
		summary.add(lblClass, gbc_lblClass);
		
		JLabel lblStr = new JLabel("STR:");
		GridBagConstraints gbc_lblStr = new GridBagConstraints();
		gbc_lblStr.insets = new Insets(0, 0, 5, 5);
		gbc_lblStr.gridx = 1;
		gbc_lblStr.gridy = 7;
		summary.add(lblStr, gbc_lblStr);
		
		JLabel lblInt = new JLabel("INT:");
		GridBagConstraints gbc_lblInt = new GridBagConstraints();
		gbc_lblInt.insets = new Insets(0, 0, 5, 5);
		gbc_lblInt.gridx = 1;
		gbc_lblInt.gridy = 8;
		summary.add(lblInt, gbc_lblInt);
		
		JLabel lblDex = new JLabel("DEX:");
		GridBagConstraints gbc_lblDex = new GridBagConstraints();
		gbc_lblDex.insets = new Insets(0, 0, 5, 5);
		gbc_lblDex.gridx = 1;
		gbc_lblDex.gridy = 9;
		summary.add(lblDex, gbc_lblDex);
		
		JLabel lblWis = new JLabel("RES:");
		GridBagConstraints gbc_lblWis = new GridBagConstraints();
		gbc_lblWis.insets = new Insets(0, 0, 5, 5);
		gbc_lblWis.gridx = 1;
		gbc_lblWis.gridy = 10;
		summary.add(lblWis, gbc_lblWis);
		
		JLabel lblChr = new JLabel("CHR:");
		GridBagConstraints gbc_lblChr = new GridBagConstraints();
		gbc_lblChr.insets = new Insets(0, 0, 5, 5);
		gbc_lblChr.gridx = 1;
		gbc_lblChr.gridy = 11;
		summary.add(lblChr, gbc_lblChr);
		
		JLabel lblSen = new JLabel("SEN:");
		GridBagConstraints gbc_lblSen = new GridBagConstraints();
		gbc_lblSen.insets = new Insets(0, 0, 5, 5);
		gbc_lblSen.gridx = 1;
		gbc_lblSen.gridy = 12;
		summary.add(lblSen, gbc_lblSen);
		
		JPanel Title = new JPanel();
		FlowLayout flowLayout = (FlowLayout) Title.getLayout();
		flowLayout.setAlignment(FlowLayout.LEFT);
		Master.add(Title, BorderLayout.NORTH);
		
		JLabel lblNewLabel = new JLabel("New Character");
		lblNewLabel.setFont(new Font("Verdana", Font.BOLD, 30));
		Title.add(lblNewLabel);
		
		this.setVisible(true);
	}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource().equals(btnNextPage)|e.getSource().equals(btnNextPage_1)|e.getSource().equals(btnNextPage_2))
		{
			CardLayout cl = (CardLayout) Center.getLayout();
			cl.next(Center);
		}
		
		if(e.getSource().equals(btnLastPage)|e.getSource().equals(btnLastPage_1)|e.getSource().equals(btnLastPage_2))
		{
			CardLayout cl = (CardLayout) Center.getLayout();
			cl.previous(Center);
		}
		
		if(e.getSource().equals(btnFinalize))
		{
			Screen s = new Screen(fl, il);
			dispose();
		}
		
	}
}
