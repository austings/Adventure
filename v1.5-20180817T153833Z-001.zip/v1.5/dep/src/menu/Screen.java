package menu;
import java.awt.Dimension;

import javax.swing.*;

import java.awt.CardLayout;
import java.awt.BorderLayout;
import javax.swing.GroupLayout.Alignment;

import packageBeta.GamePanel;
import packageBeta.GamePanelStruct;
import packageBeta.TileNode;
import packageBeta.TileThing;
import people.Creature;

import tools.Clock;
import tools.FontLibrary;
import tools.ImageLibrary;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.GraphicsEnvironment;
import java.awt.GridLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.Font;
import java.awt.ScrollPane;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Random;
import java.awt.Component;
import javax.swing.border.BevelBorder;
import java.awt.FlowLayout;
import java.io.File;
import javax.swing.border.LineBorder;


public class Screen extends JFrame implements WindowListener
{
	private GamePanelStruct[][] gps = new GamePanelStruct[50][50];
	private Dimension gpsPos = new Dimension(0,0);
	
	//panels
	private GamePanel gp ;
	private String gpTheme;
	private JPanel westPanel;
	private JTextPane timePane;
	private JTextPane datePane;
	//textoptions
	private JPanel SW_Panel;
	
	//backpack stuff
	private Backpack backpack = new Backpack(this,"Backpack",true);
	private Journal journal = new Journal(this,"Journal",true);
	private JScrollPane scrollPane = new JScrollPane();
	private DefaultListModel model = new DefaultListModel();
	private JList list;
	
	
	private Thread clockThread;
	private Clock clock;
	
	/*
	 * Construct the objects on the Screen
	 * Initiate Variables
	 */
	public Screen(FontLibrary fl, ImageLibrary il)
	{
		//JFRAME SETUP
		super();
		this.setBackground(Color.black);
		//this.setExtendedState(JFrame.MAXIMIZED_BOTH); 
		//this.setUndecorated(true);
		this.setSize(new Dimension(1680,1050));
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		
		
		
		//INITIALIZE MAP
		gpTheme= "Village";
		for (int i = 0; i < gps.length; i++) {
		    for (int j = 0; j < gps[0].length; j++) {
		        gps[i][j] = new GamePanelStruct();
		    }
		}
		//CLOCK SETTINGS//
		clock = new Clock(390,4,20);
		clockThread = new Thread(clock);
		//KEYBOARD SETUP//
		gp = new GamePanel(fl, il,new Dimension(100,100), gpTheme);
		gp.setBorder(new LineBorder(new Color(0, 0, 0), 10));
		InputMap im = gp.getInputMap(JPanel.WHEN_IN_FOCUSED_WINDOW);
		ActionMap am = gp.getActionMap();
		//movement
		im.put(KeyStroke.getKeyStroke(KeyEvent.VK_D,0), "right");
		im.put(KeyStroke.getKeyStroke(KeyEvent.VK_A,0), "left");
		im.put(KeyStroke.getKeyStroke(KeyEvent.VK_W,0), "up");
		im.put(KeyStroke.getKeyStroke(KeyEvent.VK_S,0), "down");
		im.put(KeyStroke.getKeyStroke(KeyEvent.VK_Z,0), "wait");
		//combat
		im.put(KeyStroke.getKeyStroke(KeyEvent.VK_C,0), "c");
		
		//movement
		am.put("right", new Listener("right"));
		am.put("left", new Listener("left"));
		am.put("up", new Listener("up"));
		am.put("down", new Listener("down"));
		am.put("wait", new Listener("wait"));
		//combat
		am.put("c", new Listener("c"));
		JPanel mainPanel = new JPanel();
		getContentPane().add(mainPanel, BorderLayout.CENTER);
		GridBagLayout gbl_mainPanel = new GridBagLayout();
		gbl_mainPanel.columnWidths = new int[]{405, 674, 0, 0};
		gbl_mainPanel.rowHeights = new int[]{43, 677, 50, 313, 0};
		gbl_mainPanel.columnWeights = new double[]{1.0, 0.0, 1.0, Double.MIN_VALUE};
		gbl_mainPanel.rowWeights = new double[]{1.0, 0.0, 1.0, 1.0, Double.MIN_VALUE};
		mainPanel.setLayout(gbl_mainPanel);
		
		//BACKPACK STUFF
		backpack.addWindowListener(this);
		
		//listener for pickup menu
		MouseListener mouseListener = new MouseAdapter() {
		    public void mouseClicked(MouseEvent e) {
		    	String selectedItem = (String) (((JList) e.getSource()).getSelectedValue());
		    	LinkedList<TileThing> tt = backpack.getGround();
		        for(TileThing t: tt)
		        {
					String itemName = t.getName();
					if(itemName.length()>20)
					{
						itemName = itemName.substring(0,20)+"...";
					}
		        	if(itemName.equals(selectedItem))
		        	{
		        		gp.addNotification("You picked up the "+selectedItem+".", "[Internal Narrator]");
		        		gp.getPlayer().addToInventory(true, t);
		        		//add it to the backpack
		        		backpack.addToBackpack(t);
		        		//remove it from the ground
		        		tt.remove(t);
		        		//update the ground
		        		backpack.setGround(tt);
		        		//remove it from the groundview, repaint
						model.removeAllElements();
						for(TileThing ttt:backpack.getGround())
						{
							itemName = ttt.getName();
							if(itemName.length()>20)
							{
								itemName = itemName.substring(0,20)+"...";
							}
							if(!(ttt instanceof Creature))
								model.addElement(itemName);
						}
						checks();
		        		break;
		        	}
		        }
				list = new JList(model);
				westPanel.revalidate();
				westPanel.repaint();
		        gp.requestFocus();

		    }
		};
		
		JPanel titlePanel = new JPanel();
		GridBagConstraints gbc_titlePanel = new GridBagConstraints();
		gbc_titlePanel.fill = GridBagConstraints.VERTICAL;
		gbc_titlePanel.insets = new Insets(0, 0, 5, 5);
		gbc_titlePanel.gridwidth = 2;
		gbc_titlePanel.gridx = 0;
		gbc_titlePanel.gridy = 0;
		mainPanel.add(titlePanel, gbc_titlePanel);
		titlePanel.setLayout(new GridLayout(0, 2, 500, 0));
		
		JLabel lblNewLabel = new JLabel("Title Text");
		lblNewLabel.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel.setFont(new Font("Yu Gothic Medium", Font.BOLD, 20));
		titlePanel.add(lblNewLabel);
		
		JPanel panel = new JPanel();
		titlePanel.add(panel);
		
		JButton btnNewButton_2 = new JButton("Exit");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		GridBagConstraints gbc_btnNewButton_2 = new GridBagConstraints();
		gbc_btnNewButton_2.fill = GridBagConstraints.HORIZONTAL;
		gbc_btnNewButton_2.insets = new Insets(0, 0, 5, 0);
		gbc_btnNewButton_2.gridx = 2;
		gbc_btnNewButton_2.gridy = 0;
		mainPanel.add(btnNewButton_2, gbc_btnNewButton_2);
		
		//DRAWING WINDOWS//
		westPanel = new JPanel();
		westPanel.setBorder(new LineBorder(new Color(153, 102, 0), 2, true));
		GridBagConstraints gbc_westPanel = new GridBagConstraints();
		gbc_westPanel.fill = GridBagConstraints.BOTH;
		gbc_westPanel.insets = new Insets(0, 0, 5, 5);
		gbc_westPanel.gridx = 0;
		gbc_westPanel.gridy = 1;
		mainPanel.add(westPanel, gbc_westPanel);
		westPanel.setLayout(new GridLayout(1, 1, 10, 0));
		
		
		//NOTIFICATION STANDARD
		JPanel panel_4 = new JPanel();
		westPanel.add(panel_4);
		panel_4.setLayout(new BorderLayout(5, 0));
		
		JLabel lbltag = new JLabel("[Internal Narrator]");
		panel_4.add(lbltag, BorderLayout.WEST);
		
		JTextPane txtpnWelcomeToDeremor = new JTextPane();
		txtpnWelcomeToDeremor.setEditable(false);
		txtpnWelcomeToDeremor.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtpnWelcomeToDeremor.setText("Welcome to Deremor. You've just arrived in a new village here so do what you can to make a name for yourself.");
		panel_4.add(txtpnWelcomeToDeremor, BorderLayout.CENTER);
		
		//DISPLAY
		GridBagConstraints gbc_gp = new GridBagConstraints();
		gbc_gp.fill = GridBagConstraints.BOTH;
		gbc_gp.insets = new Insets(0, 0, 5, 5);
		gbc_gp.gridx = 1;
		gbc_gp.gridy = 1;
		mainPanel.add(gp, gbc_gp);
		gp.setFocusable(true);
		gp.setDoubleBuffered(true);
		gp.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		JPanel eastpanel = new JPanel();
		GridBagConstraints gbc_eastpanel = new GridBagConstraints();
		gbc_eastpanel.insets = new Insets(0, 0, 5, 0);
		gbc_eastpanel.fill = GridBagConstraints.BOTH;
		gbc_eastpanel.gridx = 2;
		gbc_eastpanel.gridy = 1;
		mainPanel.add(eastpanel, gbc_eastpanel);
		GridBagLayout gbl_eastpanel = new GridBagLayout();
		gbl_eastpanel.columnWidths = new int[]{190, 218, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_eastpanel.rowHeights = new int[]{245, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_eastpanel.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gbl_eastpanel.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		eastpanel.setLayout(gbl_eastpanel);
		
		JLabel lblLaindirTheLost = new JLabel("Laindir the Lost");
		GridBagConstraints gbc_lblLaindirTheLost = new GridBagConstraints();
		gbc_lblLaindirTheLost.insets = new Insets(0, 0, 5, 5);
		gbc_lblLaindirTheLost.gridx = 1;
		gbc_lblLaindirTheLost.gridy = 0;
		eastpanel.add(lblLaindirTheLost, gbc_lblLaindirTheLost);
		
		JLabel lblHp = new JLabel("HP");
		GridBagConstraints gbc_lblHp = new GridBagConstraints();
		gbc_lblHp.insets = new Insets(0, 0, 5, 5);
		gbc_lblHp.gridx = 0;
		gbc_lblHp.gridy = 1;
		eastpanel.add(lblHp, gbc_lblHp);
		
		JTextPane textPane_3 = new JTextPane();
		GridBagConstraints gbc_textPane_3 = new GridBagConstraints();
		gbc_textPane_3.insets = new Insets(0, 0, 5, 5);
		gbc_textPane_3.gridx = 1;
		gbc_textPane_3.gridy = 1;
		eastpanel.add(textPane_3, gbc_textPane_3);
		textPane_3.setText("1");
		
		JLabel lblStr = new JLabel("STR");
		GridBagConstraints gbc_lblStr = new GridBagConstraints();
		gbc_lblStr.insets = new Insets(0, 0, 5, 5);
		gbc_lblStr.gridx = 0;
		gbc_lblStr.gridy = 2;
		eastpanel.add(lblStr, gbc_lblStr);
		
		JTextPane textPane_1 = new JTextPane();
		GridBagConstraints gbc_textPane_1 = new GridBagConstraints();
		gbc_textPane_1.insets = new Insets(0, 0, 5, 5);
		gbc_textPane_1.gridx = 1;
		gbc_textPane_1.gridy = 2;
		eastpanel.add(textPane_1, gbc_textPane_1);
		
		JLabel lblDex = new JLabel("DEX");
		GridBagConstraints gbc_lblDex = new GridBagConstraints();
		gbc_lblDex.insets = new Insets(0, 0, 5, 5);
		gbc_lblDex.gridx = 0;
		gbc_lblDex.gridy = 3;
		eastpanel.add(lblDex, gbc_lblDex);
		
		JTextPane textPane_2 = new JTextPane();
		GridBagConstraints gbc_textPane_2 = new GridBagConstraints();
		gbc_textPane_2.insets = new Insets(0, 0, 5, 5);
		gbc_textPane_2.gridx = 1;
		gbc_textPane_2.gridy = 3;
		eastpanel.add(textPane_2, gbc_textPane_2);
		
		JLabel lblInt = new JLabel("INT");
		GridBagConstraints gbc_lblInt = new GridBagConstraints();
		gbc_lblInt.insets = new Insets(0, 0, 5, 5);
		gbc_lblInt.gridx = 0;
		gbc_lblInt.gridy = 4;
		eastpanel.add(lblInt, gbc_lblInt);
		
		JTextPane strText = new JTextPane();
		GridBagConstraints gbc_strText = new GridBagConstraints();
		gbc_strText.insets = new Insets(0, 0, 5, 5);
		gbc_strText.gridx = 1;
		gbc_strText.gridy = 4;
		eastpanel.add(strText, gbc_strText);
		
		//ADD BUTTONS
		JButton btnItems = new JButton("Items");
		GridBagConstraints gbc_btnItems = new GridBagConstraints();
		gbc_btnItems.insets = new Insets(0, 0, 5, 5);
		gbc_btnItems.gridx = 1;
		gbc_btnItems.gridy = 8;
		eastpanel.add(btnItems, gbc_btnItems);
		
		JButton btnJrnl = new JButton("Journal");
		GridBagConstraints gbc_btnJrnl = new GridBagConstraints();
		gbc_btnJrnl.insets = new Insets(0, 0, 5, 5);
		gbc_btnJrnl.gridx = 1;
		gbc_btnJrnl.gridy = 9;
		eastpanel.add(btnJrnl, gbc_btnJrnl);
		
		JButton btnStats = new JButton("Stats");
		GridBagConstraints gbc_btnStats = new GridBagConstraints();
		gbc_btnStats.insets = new Insets(0, 0, 5, 5);
		gbc_btnStats.gridx = 1;
		gbc_btnStats.gridy = 10;
		eastpanel.add(btnStats, gbc_btnStats);
		
		JButton btnSleep = new JButton("Sleep");
		GridBagConstraints gbc_btnSleep = new GridBagConstraints();
		gbc_btnSleep.insets = new Insets(0, 0, 5, 5);
		gbc_btnSleep.gridx = 1;
		gbc_btnSleep.gridy = 11;
		eastpanel.add(btnSleep, gbc_btnSleep);
		
		JButton btnNewButton = new JButton("Save");
		GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
		gbc_btnNewButton.insets = new Insets(0, 0, 0, 5);
		gbc_btnNewButton.gridx = 1;
		gbc_btnNewButton.gridy = 12;
		eastpanel.add(btnNewButton, gbc_btnNewButton);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		//sleeping commands
		btnSleep.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				Random r = new Random();
				int c = r.nextInt(2000)+500;
				int hours = ((15*c)/60)/60;
				int minutes=((15*c)/60)-(60*hours);
				while(c!=0)
				{
					clock.run();
					gp.moveCreatures();
					c--;
				}
				gp.addNotification("You slept for "+hours+" hours and "+minutes+" minutes.", "[Internal Narrator]");
				checks();
				
			}
		});
		btnJrnl.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e)
			{
				journal.setVisible(true);
				
			}
			
		});
		btnItems.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				backpack.setVisible(true);
				backpack.setModal(true);
				
			}
		});
		
		JPanel Center_Panel = new JPanel();
		GridBagConstraints gbc_Center_Panel = new GridBagConstraints();
		gbc_Center_Panel.fill = GridBagConstraints.VERTICAL;
		gbc_Center_Panel.insets = new Insets(0, 0, 5, 5);
		gbc_Center_Panel.gridx = 1;
		gbc_Center_Panel.gridy = 2;
		mainPanel.add(Center_Panel, gbc_Center_Panel);
		
		SW_Panel = new JPanel();
		GridBagConstraints gbc_SW_Panel = new GridBagConstraints();
		gbc_SW_Panel.insets = new Insets(0, 0, 0, 5);
		gbc_SW_Panel.fill = GridBagConstraints.BOTH;
		gbc_SW_Panel.gridx = 0;
		gbc_SW_Panel.gridy = 3;
		mainPanel.add(SW_Panel, gbc_SW_Panel);
		SW_Panel.setLayout(new GridLayout(8, 1, 0, 0));
		
		JPanel southPanel = new JPanel();
		GridBagConstraints gbc_southPanel = new GridBagConstraints();
		gbc_southPanel.insets = new Insets(0, 0, 0, 5);
		gbc_southPanel.fill = GridBagConstraints.BOTH;
		gbc_southPanel.gridx = 1;
		gbc_southPanel.gridy = 3;
		mainPanel.add(southPanel, gbc_southPanel);
		southPanel.setLayout(new BorderLayout(0, 0));
		
		JPanel panel_1 = new JPanel();
		southPanel.add(panel_1, BorderLayout.CENTER);
		panel_1.setLayout(new BorderLayout(0, 0));
		//pickup menu
		list	   = new JList(model);
		list.setFont(new Font("Franklin Gothic Medium", Font.BOLD, 25));
		scrollPane = new JScrollPane(list);
		panel_1.add(scrollPane);
		list.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		list.setLayoutOrientation(JList.HORIZONTAL_WRAP);
		list.setVisibleRowCount(10);
		
		JLabel lblNearbyItems = new JLabel("Ground");
		scrollPane.setColumnHeaderView(lblNearbyItems);
		
		JPanel SE_Panel = new JPanel();
		GridBagConstraints gbc_SE_Panel = new GridBagConstraints();
		gbc_SE_Panel.fill = GridBagConstraints.BOTH;
		gbc_SE_Panel.gridx = 2;
		gbc_SE_Panel.gridy = 3;
		mainPanel.add(SE_Panel, gbc_SE_Panel);
		
		JPanel Time_Panel = new JPanel();
		SE_Panel.add(Time_Panel, BorderLayout.CENTER);
		Time_Panel.setLayout(new BorderLayout(0, 0));
		
		JPanel panel_2 = new JPanel();
		Time_Panel.add(panel_2);
		
		JLabel lblTime = new JLabel("Time");
		panel_2.add(lblTime);
		lblTime.setFont(new Font("Franklin Gothic Medium", Font.BOLD | Font.ITALIC, 15));
		
		timePane = new JTextPane();
		panel_2.add(timePane);
		timePane.setFont(new Font("Franklin Gothic Medium", Font.BOLD | Font.ITALIC, 45));
		timePane.setEditable(false);
		timePane.setText(clock.getTime());
		
		JPanel panel_3 = new JPanel();
		Time_Panel.add(panel_3, BorderLayout.NORTH);
		
		JLabel lblDate = new JLabel("Date");
		panel_3.add(lblDate);
		lblDate.setFont(new Font("Franklin Gothic Medium", Font.BOLD | Font.ITALIC, 15));
		lblDate.setHorizontalAlignment(SwingConstants.LEFT);
		
		//DISPLAY TIME/DATE
		datePane = new JTextPane();
		panel_3.add(datePane);
		datePane.setEditable(false);
		datePane.setFont(new Font("Franklin Gothic Medium", Font.BOLD | Font.ITALIC, 45));
		datePane.setText(clock.getDate());
		list.addMouseListener(mouseListener);
		this.setVisible(true);

	}
	
	//
	//Checks for night time
	//
	private boolean night= false;//boolean for night method
	public void nightCheck()
	{
		if( (((clock.hours>=8)&&(!clock.am))&&(clock.hours!=12))
				| (((clock.hours<5)&&(clock.am))|((clock.hours==12)&(clock.am))) )
		{
			if(!night)
			{
				gp.setNight(true);
				night = true;
			}
		}
		else
		{
			if(night)
			{
				night = false;
				gp.setNight(false);
			}
		}
	}
	
	/*
	 * Keyboard listener
	 */
	public class Listener extends AbstractAction
	{
		private String btn ="";
		private boolean running;
		
		public Listener(String s)
		{
			requestFocus();
			btn = s;
			running = false;
		}
		
		public void actionPerformed(ActionEvent e) {
			
			gp.getAlignmentX();
			System.out.println(clock.getTime());
			//arrow keys
			if(btn.equalsIgnoreCase("right")||
					btn.equalsIgnoreCase("left")||
					btn.equalsIgnoreCase("up")||
					btn.equalsIgnoreCase("down"))
			{
	
				//move the player, and get the tile they move to
				gp.movePlayer(btn);
			}
			//wait a turn
			if(btn.equalsIgnoreCase("wait"))
			{
			}
			//cast a spell
			if(btn.equalsIgnoreCase("c"))
			{
				System.out.println("c");
				gp.castSpell(gp.getPlayer());
			}
			checks();
		}
	}
	
	@SuppressWarnings("deprecation")
	public void checks()
	{
		//
		//CHECKS AFTER EACH TURN
		//
		//run 15 seconds
		clock.run();
		//DIALOGUE CHECKS
		//get dialogue options if any
		final JButton[] textChoice = gp.getTextOptions();
		//clear chat buttons
		SW_Panel.removeAll();
		//
		//For each one of the text option sections (there are ten), see if 
		//there is an available dialogue option to select (len >2), and if it doesn't have a actionlistener yet (len <1), add them.
		//
		for(int i =gp.responses-1;i>-1;i--)
		{
			if((textChoice[i].getText().length())>2)
			{
				if(textChoice[i].getActionListeners().length<1)
				{
					final int j = i;
					if(textChoice[i].getText().equals("Goodbye."))
					{
						//text choice action, if it is clicked.
						(textChoice[i]).addActionListener(new ActionListener() 
						{
							public void actionPerformed(ActionEvent e) 
							{
								gp.addNotification(textChoice[j].getText(),"[player]");
								gp.removeTextOptions();
								checks();
							}
						}
						);
					}
					else
					{
						(textChoice[i]).addActionListener(new ActionListener() 
						{
							public void actionPerformed(ActionEvent e) 
							{
								gp.addNotification(textChoice[j].getText(),"[player]");
								String dialogue = gp.getChatTree().readFromFile(textChoice[j].getText());
								gp.addNotification(dialogue,"["+gp.getChatTree().getCreature().getImageID()+"]");
								//Open the merchant window if the dialogue has to do with trading
								if(dialogue.contains("Take a look at my wares."))
								{
									//i needed to store the players backpack in both in the player object (inherited from creature) and backpack object so be sure to update both.
									//its really not needed, as long as i always reference the backpack object instead of the player. The problem was that the backpack was created
									//before i decided i needed to give creatures an inventory aswell. Because player is a creature it inherited that list
									MerchantScreen ms = new MerchantScreen(Screen.this, gp.getChatTree().getCreature().getName()+"'s Shop",true,backpack.getBag(),gp.getChatTree().getCreature().getInventory(),
											gp.getPlayer().getGold(),gp.getChatTree().getCreature().getGold());
								}
								checks();
							}
						}
						);
					}
				}
				SW_Panel.add(textChoice[i]);
			}
		}
		
		JPanel[] messages = gp.getNotifications();
		westPanel.removeAll();
		westPanel.setLayout(new GridLayout(gp.notifications, 1, 50, 20));
		for(int i =gp.notifications-1;i>-1;i--)
		{
			westPanel.add(messages[i]);
		}
		//update player position
		Dimension xy = gp.getPlayer().getPosition();
		TileNode n = gp.getNode(xy);
		
		//item view list
		//update the view for what items the player sees
		backpack.setGround(n.getItems());
		
		model.removeAllElements();
		for(TileThing t:backpack.getGround())
		{
			if(!(t instanceof Creature)){
				String itemName = t.getName();
				if(itemName.length()>20)
				{
					itemName = itemName.substring(0,20)+"...";
				}
				model.addElement(itemName);}
		}
		list = new JList(model);
		
		//MoveMonsters
		gp.moveCreatures();
		gp.setDate(clock.getDate());
		
		//pass time and continue. each action takes 15 seconds
		nightCheck();
		datePane.setText(clock.getDate());
		timePane.setText(clock.getTime());
		
		
		//change to new screen
		//System.out.print(gpsPos.height);
		
		//if left side
		if(gp.getPlayer().getPosition().getWidth()==1)
		{
			
		}
		//if bottom side
		if(gp.getPlayer().getPosition().getHeight()==99)
		{
			
		}
		//if right side
		if(gp.getPlayer().getPosition().getWidth()==99)
		{
			//get current map position
			int y = gpsPos.height;
			int x = gpsPos.width;
			//discover get previous worldView
			gps[x][y].discovered=true;
			gps[x][y].worldView=gp.getPlayer().getWorldView();
			//remove player from that worldView
			//gps[x][y].worldView[gp.getPlayer().getPosition().width][gp.getPlayer().getPosition().height].removeItem(gp.getPlayer().getCallNum());
			
			if(gps[x][y].discovered==false)
			{
				gp.generateNewWorld(new Dimension(50,1), "Village");
			}
					
			gpsPos.width++;
		}
		//if Top side
		if(gp.getPlayer().getPosition().getHeight()==1)
		{
			
		}
		//if top side
		
		//if bottom side
		
		westPanel.repaint();	
		westPanel.validate();
		westPanel.revalidate();
		validate();
		revalidate();
		repaint();
	}
	
	public void windowActivated(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	public void windowClosed(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	/*
	 * This may need to be modified to only occur when accessing the backpack
	 */
	public void windowClosing(WindowEvent e) 
	{
		TileNode n = gp.getNode(new Dimension(gp.getPlayer().getPosition()));
		for(TileThing t: backpack.getDropList())
		{
			gp.getPlayer().addToInventory(false, t);
			n.addItem(t);
		}
		backpack.clearDropList();
		gp.setNode(new Dimension(gp.getPlayer().getPosition()),n);
		validate();
		repaint();
		
	}

	public void windowDeactivated(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	public void windowDeiconified(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	public void windowIconified(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	public void windowOpened(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	


}

/*
 * 
 * MOVE DIAGONALLY
			if(btn.equalsIgnoreCase("q"))
			{
				//move the player, and get the tile they move to
				if(gp.movePlayer("left",null)==1)
				{
					clock.run();
					if(gp.movePlayer("up",null)==1)
						clock.run();
				}
				else{
					if(gp.movePlayer("up",null)==1)
						clock.run();
					if(gp.movePlayer("left",null)==1)
						clock.run();
					}
			}
			if(btn.equalsIgnoreCase("e"))
			{
				if(gp.movePlayer("up",null)==1)
				{
					clock.run();
					if(gp.movePlayer("right",null)==1)
						clock.run();
				}
				else{
					if(gp.movePlayer("right",null)==1)
						clock.run();
					if(gp.movePlayer("up",null)==1)
						clock.run();
				}
			}
			if(btn.equalsIgnoreCase("z"))
			{
				if(gp.movePlayer("down",null)==1)
				{
					clock.run();
					if(gp.movePlayer("left",null)==1)
						clock.run();
				}
				else{
					if(gp.movePlayer("left",null)==1)
						clock.run();
					if(gp.movePlayer("down",null)==1)
						clock.run();
				}
			}
			if(btn.equalsIgnoreCase("c"))
			{
				if(gp.movePlayer("down",null)==1)
				{
					clock.run();
					if(gp.movePlayer("right",null)==1)
						clock.run();
				}
				else{
					if(gp.movePlayer("right",null)==1)
						clock.run();
					if(gp.movePlayer("down",null)==1)
						clock.run();
				}
			}
 */