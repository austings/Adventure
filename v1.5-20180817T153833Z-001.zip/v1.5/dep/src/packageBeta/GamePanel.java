package packageBeta;

import java.awt.AlphaComposite;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import people.*;
import tools.Dice;
import tools.FontLibrary;
import tools.ImageLibrary;
import tools.ItemLibrary;
import tools.ModuleLibrary;
import tools.Spellbook;

import javax.imageio.ImageIO;
import javax.swing.*;

public class GamePanel extends JPanel
{
	//world information
	private Dimension size;
	private String theme;
	private TileNode[][] world;//the world on screen
	private TileNode[][] worldView;//the entire world
	private ArrayList<Creature> creatures = new ArrayList<Creature>();//all creatures
	//responses box
	public int responses = 10;
	private JButton[] jb = new JButton[10];
	
	//message,notification box
	private JPanel[] messages = new JPanel[8];
	private ChatTree ct = new ChatTree(-1);
	public int notifications=1;
	
	//Image stuff
	private ImageLibrary lib;
	private BufferedImage previousFloorImage;//floor image previous to when player stepped on tile
	private int previousFloorImageID;//id of that image
	private Player p; //current position of the player
	
	//time
	private boolean night;
	private String date;
	
	//Item Stuff
	private ItemLibrary il = new ItemLibrary();
	
	/**
	 * Constructor. Sets up the Gameworld and the way we view it.
	 * @param size- dimensions of the world.
	 */
	
	public GamePanel(FontLibrary fl, ImageLibrary il, Dimension size, String theme)
	{
		lib = il;
		this.setSize(672,672);
		this.theme = theme;
		//GRAPHICS SETUP//
		//create our library of tiles to paint the world with
		previousFloorImage = lib.get(-1);
		
		//activate messages
		JPanel panel = new JPanel();
		messages[0]=panel;
		messages[1]=panel;
		messages[2]=panel;
		messages[3]=panel;
		messages[4]=panel;
		messages[5]=panel;
		messages[6]=panel;
		messages[7]=panel;
		//activate buttons
		JButton button = new JButton();
		jb[0]=button;
		jb[1]=button;
		jb[2]=button;
		jb[3]=button;
		jb[4]=button;
		jb[5]=button;
		jb[6]=button;
		jb[7]=button;
		jb[8]=button;
		jb[9]=button;
		//WORLD SETUP//
		//create the new world

		this.size = size;
		Dimension start = new Dimension(size.width/2,size.height/2);
		p = new Player("Laindir",start);
		generateNewWorld(start, theme);
	}
	
	public void generateNewWorld(Dimension playerStart, String theme)
	{
		int x = size.width;
		int y = size.height;
		this.theme = theme;
		
		worldView = new TileNode[x][y];
		//Create a blank world by looping through the size of the map
		//and creating tiles for each grid block
		for(int i = x-1;i>=0;i--)
		{
			for(int j = y-1; j>=0;j--)
			{

				//creates a blank world
				worldView[i][j] = new TileNode(-1,i,j);
			}
		}
		//place corner blocks
		for(int i =0;i<100;i++)
		{
			worldView[i][1].setImage(-2);
			worldView[y-1][i].setImage(-8);
			worldView[1][i].setImage(-9);
			worldView[i][y-1].setImage(-5);
			
		}
		worldView[1][1].setImage(-4);
		worldView[y-1][y-1].setImage(-7);
		worldView[1][y-1].setImage(-6);
		worldView[y-1][1].setImage(-3);
		
		//add player to world
		p.setPosition(playerStart);
		worldView[playerStart.width][playerStart.height].addItem(p);
		//paint stuff in the world
		paintModules();
		//addNPCs
		addNPCs();
		addThings();

		//WORLD VIEW SETUP//
			
		//get screen viewport (player starts at center of map)
		world = new TileNode[21][21];
		
		//this is the x and y coordinates of the top left position
		//the player can see. On a 100x100 grid this is position 40
		x = (playerStart.width)-10;//40 on 100x100
		y = (playerStart.height)-10;//40 on 100x100
		int worldx=0;
		int worldy=0;
		//
		for(int i = x;worldx!=21;i++)
		{
			for(int j = y; worldy!=21;j++)
			{

				//creates a blank world
				TileNode n = worldView[i][j];
				world[worldx][worldy] = n;
				worldy++;
			}
			worldy = 0;
			worldx++;
		}
		

		repaint();
	}
	
	public void addThings()
	{
		
		//Add Books
		worldView[32][30].addItem(il.getItem("Deremor Vol I"));
		
		worldView[50][51].addItem(new TileThing("Rock"));
		worldView[50][49].addItem(new TileThing("Toad"));
		worldView[49][50].addItem(new TileThing("Napkin"));
		worldView[51][50].addItem(new TileThing("Turtle"));
		worldView[50][50].addItem(new TileThing("Pickle"));
		worldView[50][51].addItem(new TileThing("Fishstick"));
		worldView[50][49].addItem(new TileThing("Shoe"));
		worldView[51][50].addItem(new TileThing("Really long item name, of excalibur"));
	}
	
	/*
	 * Method to add Creatures into the world
	 */
	public void addNPCs()
	{
		Creature eldwir = new Creature("Eldwir", new Dimension(45,45),1000);
		eldwir.addAttribute("Friendly");
		TileThing bol = new TileThing("Book of Lore");
		TileThing blackInk = new TileThing("Black Ink");
		TileThing goldCrown = new TileThing("Gold Crown");
		
		eldwir.addToInventory(true, new TileThing("Book of Lore"));
		eldwir.addGold(1000);
		Creature pahlin = new Creature("Princess Pahlin", new Dimension(60,60),1001);
		pahlin.addAttribute("Friendly");
		Creature cowboy = new Creature("Sheriff Wilson",new Dimension(52,52),1002);
		cowboy.addAttribute("Friendly");
		//pahlin.walkingBehaviour = new String("true random");
		Creature wolf = new Creature("Wolf", new Dimension(51,51),1003);
		cowboy.addAttribute("Hostile");
		creatures.add(eldwir);
		creatures.add(pahlin);
		creatures.add(cowboy);
		creatures.add(wolf);
		worldView[45][45].addItem(eldwir);
		worldView[52][52].addItem(cowboy);
		worldView[60][60].addItem(pahlin);
		worldView[51][51].addItem(wolf);
	}
	
	/*
	 * Method to paint different modules, (homes, areas, etc).
	 */
	public void paintModules()
	{
		ModuleLibrary ml = new ModuleLibrary();
		
		int NumOfFailures = 0;
		while(NumOfFailures<ml.getDensity())
		{
			Dice dice = new Dice(20);
			if(dice.roll()>16)
			{
				ml.setModule(1);
			}
			else
			{
				ml.setModule(0);
			}
			Random r = new Random();
			int resultx = r.nextInt(size.width-1)+1;
			int resulty = r.nextInt(size.height-1)+1;
			
			int xStart = 0;
			int yStart = 0;
			
			Dimension d = ml.getModuleSize();
			
			int modulelength = d.height;
			int modulewidth = d.width;
			boolean fail = false;
			
			if(((resultx+modulewidth)<size.width)&((resulty+modulelength)<size.height))
			{
				while(xStart<modulewidth)
				{
					while(yStart<modulelength)
					{
						if(worldView[resultx+xStart][resulty+yStart].isSolid())
						{
							xStart=modulewidth;
							yStart=modulelength;
							fail = true;
						}
						yStart++;
					}
					yStart = 0;
					xStart++;
				}
				xStart=0;
				
				if(!fail)
				{
					worldView = ml.returnAddedModule(worldView, resultx, resulty);
				}
				else
				{
					NumOfFailures++;
				}
			}
		}
		
	}
	
	/**
	 * Gets each tile's image and repaints it.
	 */
	public void paint(Graphics g)
	{
		this.removeAll();
		this.updateUI();
		int coordx = 0;
		int coordy = 0;
		//g.drawImage(lib.get(0),0,0,null);
			
		//go through each tile and draw its image
		for(int x = 0;x!=21;x++)
		{
			for(int y=0;y!=21;y++)
			{
				g.drawImage(lib.get(world[x][y].getID()), coordx, coordy,null);
				coordy= coordy+32;
			}
			coordy = 0;
			coordx = coordx+32;
		}
		//if its night time, draw a transparent dark layer
		if(night)
		{
			int alpha = 127; // 50% transparent
			Color myColour = new Color(0, 0, 50, alpha);
			g.setColor(myColour);
			g.fillRect(0, 0, 675, 675);
		}
	}
	
	public JPanel[] getNotifications()
	{
		return messages;
	}
	
	public JButton[] getTextOptions()
	{
			return jb;
	}
	
	public void removeTextOptions()
	{
		JButton button = new JButton();
		jb[0]=button;
		jb[1]=button;
		jb[2]=button;
		jb[3]=button;
		jb[4]=button;
		jb[5]=button;
		jb[6]=button;
		jb[7]=button;
		jb[8]=button;
		jb[9]=button;
		ct = new ChatTree(-1);
	}
	
	public ChatTree getChatTree()
	{
		return ct;
	}
	
	public void closeChatTree()
	{
		for(Creature c: creatures)
		{
			if(c.getCallNum()==ct.getCreature().getCallNum())
			{
				c.setTalking(false);
			}
		}
		ct = new ChatTree(-1);
	}
	
	public void setChatTree(ChatTree ct)
	{
		this.ct = ct;
	}
	
	
	/**
	 * Initiate dialogue with a nonhostile creature
	 */
	public void dialogue(Creature i)
	{
		if(!i.hasAttribute("Hostile"))
		{
			ct = new ChatTree(i);
			addNotification(ct.getResponse(),"["+i.getImageID()+"]");
			ArrayList<String> response = ct.getChoices();
			int k = 0;
			for(String r: response)//for each string in responses create a new button and assign to array 
			{
				jb[k] = new JButton(r);
				k++;
			}
				
		}
		else
		{
		}
	}
	
	public void pNotify(String text)
	{
		int i = 7;
		JPanel panel = new JPanel();
		panel.setPreferredSize(new Dimension(900,200));
		panel.setLayout(new BorderLayout(5, 0));
		
		BufferedImage myPicture = lib.get(p.getImageID());
		JLabel lbltag = new JLabel(new ImageIcon(myPicture));
		panel.add(lbltag, BorderLayout.EAST);
		JTextPane txt = new JTextPane();
		txt.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txt.setText(text);
		txt.setEditable(false);
		panel.add(txt, BorderLayout.CENTER);
		while(i>0)
		{
			messages[i] = messages[i-1];
			i--;
		}
		messages[0]=panel;
		notifications++;
		if(notifications>8){
			notifications--;}
		
		
	}
	
	public void addNotification(String message, String tag)
	{
		int i = 7;
		JPanel panel = new JPanel();
		panel.setPreferredSize(new Dimension(900,200));
		panel.setLayout(new BorderLayout(5, 0));
		
		//add pictures
		if(tag.equals("[1000]"))//noble
		{
			BufferedImage myPicture = lib.get(10000);
			JLabel lbltag = new JLabel(new ImageIcon(myPicture));
			panel.add(lbltag, BorderLayout.WEST);
		}else{
		if(tag.equals("[1001]"))//lady
		{
			BufferedImage myPicture = lib.get(10001);
			JLabel lbltag = new JLabel(new ImageIcon(myPicture));
			panel.add(lbltag, BorderLayout.WEST);
		}else{
		if(tag.equals("[1002]"))//cowboy
		{
			BufferedImage myPicture = lib.get(10002);
			JLabel lbltag = new JLabel(new ImageIcon(myPicture));
			panel.add(lbltag, BorderLayout.WEST);
		}else{
		if(tag.equals("[1]"))//player
		{
			BufferedImage myPicture = lib.get(1);
			JLabel lbltag = new JLabel(new ImageIcon(myPicture));
			panel.add(lbltag, BorderLayout.WEST);
		}
		else
		{//will just use the tag string
			JLabel lbltag = new JLabel(tag);
			panel.add(lbltag, BorderLayout.WEST);
		}}}}
		
		JTextPane txt = new JTextPane();
		txt.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txt.setText(message);
		txt.setEditable(false);
		panel.add(txt, BorderLayout.CENTER);
		while(i>0)
		{
			messages[i] = messages[i-1];
			i--;
		}
		messages[0]=panel;
		notifications++;
		if(notifications>8){
			notifications--;}
	}
	
	/*
	 * Change the night on or off
	 */
	public void setNight(boolean t)
	{
		night = t;
	}
	
	public void setDate(String d)
	{
		date = d;
	}
	/*
	 * INCOMPLETE 
	 * cast a spell 
	 */
	public void castSpell(Creature c)
	{
		//int x= c.getPosition().width;
		//int y = c.getPosition().height;
		//String lld = c.getLastLookedDirection();
		//Spellbook sb = c.getSpellbook();
		//sb.castSpell("Fireball", worldView, x, y, lld);
		
	}
	
	/*
	 * Method called when user presses one of the arrow keys, or
	 * a send it a creature and it will move the creature instead.
	 * 
	 * This method should move the player tile on the worldView, then 
	 * adjust the world on the screen 
	 * @parameter String string- the direction of the arrow key pressed
	 * 
	 */
	public int movePlayer(String string) 
	{
		//get players int coords
		int x = p.getPosition().width;
		int y = p.getPosition().height;
		
		
		//
		//
		//System.out.println(x+" ,"+y);
		//
		//
		
		//dont move if at end of map, or if in the middle of a conversation
		if(!(x==worldView.length-1)&ct.getResponse().equals("NOT A RESPONSE"))
		{
			//if this is the direction we want
			if(string =="right")
			{
				//and if we can move onto that tile
				if(!(worldView[x+1][y].isSolid())&&(worldView[x+1][y].getID()<1))//if its solid OR someone is standing there already
				{
					//move onto it
					String uniqueid = p.getCallNum();
					worldView[x][y].removeItem(uniqueid);
					worldView[x+1][y].addItem(p);
					addNotification("You traveled east.","[Internal Narrator]");
					p.moveRight();
					//if we aren't near the end of the map, scroll
					if(x<worldView.length-11&!(x<11))
						scrollRight();
					else
						repaint();
					return 1;
				}
				worldView[x+1][y].poke(p);
				//if trying to touch a creature, initiate dialogue
				Creature c = worldView[x+1][y].getCreature();
				if(c !=null)
					dialogue(c);
			}
		}
		if(!(x<=1)&ct.getResponse().equals("NOT A RESPONSE"))
		{
			if(string =="left")
			{
				if(!(worldView[x-1][y].isSolid())&&(worldView[x-1][y].getID()<1))
				{
					String uniqueid = p.getCallNum();
					worldView[x][y].removeItem(uniqueid);
					worldView[x-1][y].addItem(p);
					addNotification("You traveled west.","[Internal Narrator]");
					p.moveLeft();
					if(x>11&!(x>worldView.length-11))
						scrollLeft();
					else
						repaint();
					return 1;
				}
				worldView[x-1][y].poke(p);
				Creature c = worldView[x-1][y].getCreature();
				if(c !=null)
					dialogue(c);
			}
		}
		if(!(y<=1)&ct.getResponse().equals("NOT A RESPONSE"))
		{
			if(string =="up")
			{
				if(!(worldView[x][y-1].isSolid())&(worldView[x][y-1].getID()<1))
				{
					String uniqueid = p.getCallNum();
					worldView[x][y].removeItem(uniqueid);
					worldView[x][y-1].addItem(p);
					p.moveUp();
					addNotification("You traveled north.","[Internal Narrator]");
					if(y>11&!(y>worldView[1].length-11))
						scrollUp();
					else
						repaint();
					return 1;
				}
				worldView[x][y-1].poke(p);
				Creature c = worldView[x][y-1].getCreature();
				if(c !=null)
					dialogue(c);
			}
		}
		if(!(y==worldView[1].length-1)&ct.getResponse().equals("NOT A RESPONSE"))
		{
			if(string =="down")
			{
				if(!(worldView[x][y+1].isSolid())&(worldView[x][y+1].getID()<1))
				{
					String uniqueid = p.getCallNum();
					worldView[x][y].removeItem(uniqueid);
					worldView[x][y+1].addItem(p);
					p.moveDown();
					addNotification("You traveled south.","[Internal Narrator]");
					if(y<worldView[1].length-11&!(y<11))
						scrollDown();
					else
						repaint();
					return 1;
				}
				worldView[x][y+1].poke(p);
				Creature c = worldView[x][y+1].getCreature();
				if(c !=null)
					dialogue(c);
			}
		}
		return 0;
	}

	
	/*
	 * Method to have each creature run their turn 
	 */
	public void moveCreatures()
	{
		//creatures = returnCreaturesByDexterity();
		for(Creature c: creatures)
		{
			c.setWorldView(worldView);
			int x = c.getPosition().width;
			int y = c.getPosition().height;
			boolean swb = c.swapSlowWalkBool();
			if(swb==false&c.getTalking()==false)
			{
				c.run();
				String s = c.getLastLookedDirection();
				if(s.equals("down"))
				{
					if(!(worldView[x][y+1].getID()>0))//if not solidobject
					{
						String uniqueid = c.getCallNum();
						worldView[x][y].removeItem(uniqueid);
						worldView[x][y+1].addItem(c);
						repaint();
					}
				}
				if(s.equals("right"))
				{
					if(!(worldView[x+1][y].getID()>0))//if not solidobject
					{
						String uniqueid = c.getCallNum();
						worldView[x][y].removeItem(uniqueid);
						worldView[x+1][y].addItem(c);
						repaint();
					}
				}
				if(s.equals("left"))
				{
					if(!(worldView[x-1][y].getID()>0))//if not solidobject
					{
						String uniqueid = c.getCallNum();
						worldView[x][y].removeItem(uniqueid);
						worldView[x-1][y].addItem(c);
						repaint();
					}
				}
				if(s.equals("up"))
				{
					if(!(worldView[x][y-1].getID()>0))//if not solidobject
					{
						String uniqueid = c.getCallNum();
						worldView[x][y].removeItem(uniqueid);
						worldView[x][y-1].addItem(c);
						repaint();
					}
				}
			}
		}
	}

	/*
	 * Return each creature by dexterity
	 */
	public Creature[] returnCreaturesByDexterity()
	{
		ArrayList<Creature> list = new ArrayList<Creature>();
		
		//
		//retrieve each creature in the world
		//
		
		list = creatures;
		
		//
		//sort by highest dex next
		//
		//not efficent but easy to implement.
		//
		Creature[] rList = new Creature[list.size()];
		
		int iterator = 0;
		int indexOfHighest = 0;
		int count = 0;
		while(list.size()!=0)
		{
			for(Creature buddy : list)
			{
				if(list.get(indexOfHighest).getDEX()<buddy.getDEX())
				{
					indexOfHighest = count;
				}
				count++;
			}
			rList[iterator]=list.get(indexOfHighest);
			list.remove(indexOfHighest);
			iterator++;
		}
		return rList;
		
		
	}
	
	public void scrollRight()
	{
		//loop through each row/column
		int x=0;
		int y=0;
		while(y<21)
		{
			//set to next image
			while(x!=20)
			{
				world[x][y] = world[x+1][y];
				x=x+1;
			}
			//last column needs to be pulled from worldview
			int wvx = world[x][y].getX();
			int wvy = world[x][y].getY();
			
			world[x][y]=worldView[wvx+1][wvy];
			x=0;
			y++;
		}
		//redraw
		repaint();

	}
	
	public TileNode getNode(Dimension xy)
	{
		return worldView[xy.width][xy.height];
	}
	
	public void setNode(Dimension xy, TileNode t)
	{
		worldView[xy.width][xy.height]= t;
		repaint();
	}
	
	public void scrollLeft()
	{
		//loop through each row/column
		int x=20;
		int y=0;
		while(y<21)
		{
			//set to next image
			while(x!=0)
			{
				world[x][y] = world[x-1][y];
				x=x-1;
			}
			int wvx = world[x][y].getX();
			int wvy = world[x][y].getY();
			
			world[x][y]=worldView[wvx-1][wvy];
			x=20;
			y++;
		}
		//redraw
		repaint();
		
	}
	
	public void scrollUp()
	{
		//loop through each row/column
		int x=0;
		int y=20;
		while(x<21)
		{
			//set to next image
			while(y!=0)
			{
				world[x][y] = world[x][y-1];
				y=y-1;
			}
			int wvx = world[x][y].getX();
			int wvy = world[x][y].getY();
			
			world[x][y]=worldView[wvx][wvy-1];
			y=20;
			x++;
		}
		//redraw
		repaint();
	}
	
	public void scrollDown()
	{
		//loop through each row/column
		int x=0;
		int y=0;
		while(x<21)
		{
			//set to next image
			while(y!=20)
			{
				world[x][y] = world[x][y+1];
				y=y+1;
			}
			int wvx = world[x][y].getX();
			int wvy = world[x][y].getY();
			
			world[x][y]=worldView[wvx][wvy+1];
			y=0;
			x++;
		}
		//redraw
		repaint();
	}

	public Player getPlayer()
	{
		return p;
	}


}
