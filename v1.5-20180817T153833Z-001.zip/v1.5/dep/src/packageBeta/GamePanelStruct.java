package packageBeta;

import java.awt.Dimension;
import java.util.ArrayList;

import javax.swing.JPanel;

import people.Creature;

public class GamePanelStruct
{
	//world information
	public boolean discovered = false;
	public TileNode[][] world;//the world on screen
	public TileNode[][] worldView;//the entire world
	
	public GamePanelStruct()
	{
		
	}

}
