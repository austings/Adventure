package tools;

import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.GraphicsEnvironment;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

public class FontLibrary 
{
	Font medReg12;
	Font medReg18;
	Font medReg36;
	
	public FontLibrary()
	{
		System.out.println("Loading Fonts");
		try {
		    //create the font to use. Specify the size!
		    GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
		    medReg12 = Font.createFont(Font.TRUETYPE_FONT,  this.getClass().getResourceAsStream("/resources/fonts/medreg.ttf")).deriveFont(12f);
		    medReg18 = Font.createFont(Font.TRUETYPE_FONT, this.getClass().getResourceAsStream("/resources/fonts/medreg.ttf")).deriveFont(18f);
		    medReg36 = Font.createFont(Font.TRUETYPE_FONT, this.getClass().getResourceAsStream("/resources/fonts/medreg.ttf")).deriveFont(36f);
		    //register the font
		    ge.registerFont(medReg12);
		    ge.registerFont(medReg18);
		    ge.registerFont(medReg36);
		} catch (Exception e) {
			System.out.println("ERROR");
		    e.printStackTrace();
		} 
	}
	
	public Font getFont(String name)
	{
		if(name.equals("medReg12"))
			return medReg12;
		if(name.equals("medReg18"))
			return medReg18;
		if(name.equals("medReg36"))
			return medReg36;
		
		return medReg12;
	}
}
