package tools;

import java.util.HashMap;

import packageBeta.TileThing;

public class ItemLibrary 
{
	private int id;
	private String itemName;
	
	private TileThing ironHelm;
	private TileThing steelHelm;
	
	private TileThing fineRBlouse;
	private TileThing bandana;
	private TileThing lglove;
	
	private TileThing testBook;
	private HashMap<String, TileThing> hm = new HashMap(200);
	
	public ItemLibrary()
	{
		createAllItems();
	}

	public void createAllItems()
	{
		createArmor();
		createClothes();
		createBooks();
	}
	
	public void createArmor()
	{
		ironHelm = new TileThing("Iron Helmet");
		ironHelm.setEquippable("helmet");
		ironHelm.setImageID(-62);
		ironHelm.setToolTipText("An iron helmet is commonly used by the pauper classes of society. <br> Most were crafted years ago and aged with rust.");
		hm.put("Iron Helmet", ironHelm);
		
		steelHelm = new TileThing("Steel Helmet");
		steelHelm.setEquippable("helmet");
		steelHelm.setToolTipText("The steel helmet is finely polished and ideal for most combat situations.");
		hm.put("Steel Helmet",steelHelm );
		
	}
	
	public void createClothes()
	{
		fineRBlouse = new TileThing("Fine Red Blouse");
		fineRBlouse.setEquippable("shirt");
		fineRBlouse.setToolTipText("A satin, gender neutral red blouse.");
		hm.put("Fine Red Blouse", fineRBlouse);
		
		bandana = new TileThing("Bandana");
		bandana.setImageID(-63);
		bandana.setEquippable("face");
		bandana.setToolTipText("Typical of many highwaymen, this bandana is very useful in <br> concealing your face.");
		hm.put("Bandana", bandana);
		
		lglove = new TileThing("Leather Gloves");
		lglove.setEquippable("glove");
		lglove.setToolTipText("These firm leather gloves are accented by interwoven threads of <br> cloth for extra flexibility.");
		hm.put("Leather Gloves",lglove);
	}
	
	public void createBooks()
	{
		testBook = new TileThing("Deremor Vol I");
		testBook.setReadable("book");
		testBook.setToolTipText("This book contains the history of the world. <br>Apparently it comes in many volumes<br>");
		hm.put( "Deremor Vol I",testBook);
	}
	
	public TileThing getItem(String key)
	{
		return hm.get(key);
	}
	
	
	public TileThing[] getCommonEquipment()
	{
		TileThing[] j = new TileThing[5];
		int i =0;
		//Add Armor Items
		
		j[i] = ironHelm;
		i++;
		
		j[i] = steelHelm;
		i++;
		
		j[i] = fineRBlouse;
		i++;
		
		j[i] = bandana;
		i++;
		
		j[i] = lglove;
		i++;
		
		
		return j;
	}
	
	public TileThing[] getCommonBook()
	{
		TileThing[] j = new TileThing[1];
		int i =0;
		//Add Books
		
		j[i] = testBook;
		i++;
		return j;
	}
	
}
