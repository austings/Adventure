package tools;

import java.util.ArrayList;

import packageBeta.TileNode;
import packageBeta.TileThing;
import people.Creature;
import people.Player;

/*
 * Class for drawing spells
 */
public class Spellbook extends TileThing
{
	private ArrayList<Spell> book;
	private ImageLibrary il = new ImageLibrary();
	private TileNode[][]worldView = null;
	private Creature owner;
	
	/*
	 * Collection of spells for each character
	 */
	public Spellbook(String name, Creature c)
	{
		super(name);
		this.owner = c;
		if(owner instanceof Player)
		{
			book = new ArrayList<Spell>();
			book.add(new Spell("Fireball",-200));
		}
	}
	
	public TileNode[][] castSpell(String spellName)
	{
		TileNode[][] world = owner.getWorld(owner.getWorldView());
		String lld = owner.getLastLookedDirection();
		if(spellName.equals("Fireball"))
		{
			int xM = 0;
			int yM = 0;
			if(lld.equals("up"))
			{
				yM=-1;
			}
			if(lld.equals("down"))
			{
				yM=1;
			}
			if(lld.equals("left"))
			{
				xM=-1;
			}
			if(lld.equals("right"))
			{
				xM=1;
			}
			world[owner.getPosition().width+xM][owner.getPosition().height+yM]
					.addItem(book.get(0));
			book.get(0).fire(world,owner.getPosition().width,owner.getPosition().height,lld);
			book.get(0).run();
		}
		return world;
	}
}
